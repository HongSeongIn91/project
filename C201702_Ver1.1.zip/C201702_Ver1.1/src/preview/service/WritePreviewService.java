package preview.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import Connection.DBConnection;
import preview.dao.PreviewDao;
import preview.model.Preview;

public class WritePreviewService {

	private PreviewDao preDao = new PreviewDao();

	public int write(WritePreviewRequest writePreReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			Preview preview = toPreview(writePreReq);
			
			Preview savedPreview = preDao.insert(conn, preview);
			if(savedPreview == null) {
				throw new RuntimeException("fail to insert preview");
			}
			
			conn.commit();
			return savedPreview.getPre_mv_num();
			
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (RuntimeException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
		
	}

	private Preview toPreview(WritePreviewRequest writePreReq) {
		
		Date now =new Date();
		
		return new Preview(
				null, 
				writePreReq.getPre_mv_num(), 
				writePreReq.getPre_m_id(), 
				now, 
				writePreReq.getPre_content()
				);
		
	}
	
	
}
