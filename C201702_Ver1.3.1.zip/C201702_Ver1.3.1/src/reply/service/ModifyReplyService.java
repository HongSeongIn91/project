package reply.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import Connection.DBConnection;
import reply.dao.ReplyDao;
import review.service.PermissionDeniedException;

public class ModifyReplyService {

	private ReplyDao replyDao = new ReplyDao();
	
	public void modify(ModifyReplyRequest modReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			replyDao.update(conn, modReq.getRp_num(), modReq.getRp_content());
			
			conn.commit();
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}
}
