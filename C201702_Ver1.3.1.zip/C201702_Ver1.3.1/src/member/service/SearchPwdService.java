package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import member.dao.MemberDao;
import member.model.Member;

public class SearchPwdService {

	private static MemberDao memberDao = new MemberDao();
	
	public Member searchPwd(String id, String phone) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			
			Member member = memberDao.selectByIdPhone(conn, id, phone);
			if(member==null) {
				throw new MemberNotFoundException();
			}
			
			String tempPwd = randomPwdGenerator();
			memberDao.updateTempPwd(conn, tempPwd, member);
			Member tempMember = memberDao.selectById(conn, id);
			
			return tempMember;
		} catch (SQLException e) {
				JdbcUtil.rollback(conn);
				throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}

	private String randomPwdGenerator() {
		
		String tempPwd = "";
		
		for(int i=0; i<8; i++) {
			int randomVal = (int)(Math.random()*62);
			if(randomVal < 10) {
				tempPwd += randomVal;
			} else if (randomVal > 35) {
				tempPwd += (char)(randomVal + 61);
			} else {
				tempPwd += (char)(randomVal + 55);
			}
		}
		return tempPwd;
	}
}
