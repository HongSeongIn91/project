package movie.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import movie.dao.MovieDao;
import movie.model.Movie;
import Connection.DBConnection;

public class ReadMovieService {

	private MovieDao movieDao  = new MovieDao();
	
	public MovieData getMovie(int mv_num, boolean increaseReadCount) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			//MOVIE_INFO 테이블에서 지정한 번호의 Movie객체를 구한다
			Movie movie = movieDao.selectByMvNum(conn, mv_num);
			//게시글 데이터가 없다면 예외처리 
			if (movie == null) {
				throw new MovieNotFoundException();
			}
	
			//increaseReadCount가 있다면 true, 조회수를 증가시킴
			if (increaseReadCount) {
				movieDao.increaseReadCount(conn, mv_num);
			}
			//MovieData객체를 리턴
			return new MovieData(movie);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
