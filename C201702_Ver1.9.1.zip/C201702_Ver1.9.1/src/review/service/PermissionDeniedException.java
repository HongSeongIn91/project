package review.service;

public class PermissionDeniedException extends RuntimeException {

}
