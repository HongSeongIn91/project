package preview.service;

import java.sql.Connection;
import java.sql.SQLException;




import javax.naming.NamingException;

import member.dao.JdbcUtil;
import Connection.DBConnection;
import preview.dao.PreviewDao;
import review.service.PermissionDeniedException;

public class ModifyPreviewService {

	private PreviewDao preDao = new PreviewDao();

	public void modify(ModifyPreviewRequest modPreReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;

		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			preDao.update(conn, modPreReq.getPre_num(), modPreReq.getPre_content());
			
			conn.commit();
			
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}
	
}
