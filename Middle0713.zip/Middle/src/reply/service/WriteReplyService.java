package reply.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import reply.model.Reply;
import reply.service.WriteReplyRequest;
import Connection.DBConnection;
import reply.dao.ReplyDao;

public class WriteReplyService {

	private ReplyDao replyDao = new ReplyDao();

	public Integer write(WriteReplyRequest req) throws ClassNotFoundException, NamingException {
			Connection conn = null;
		
			try {
				conn = DBConnection.getConnection();
				conn.setAutoCommit(false);
				
				Reply reply = toReply(req);
				
				Reply savedReply = replyDao.insert(conn, reply);
				if(savedReply == null) {
					throw new RuntimeException("fail to insert reply");
				}
				
				conn.commit();
				return savedReply.getRp_rv_num();
	
			} catch (SQLException e) {
				JdbcUtil.rollback(conn);
				throw new RuntimeException(e);
			} catch (RuntimeException e) {
				JdbcUtil.rollback(conn);
				throw e;
			} finally {
				JdbcUtil.close(conn);
			}
	
		}
	
	private Reply toReply(WriteReplyRequest req) {
		Date now =  new Date();
		return new Reply(null, req.getRp_rv_num(), req.getRp_m_id(), now, req.getRp_content());
	}
}