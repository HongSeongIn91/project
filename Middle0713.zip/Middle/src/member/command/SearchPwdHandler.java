package member.command;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.model.Member;
import member.service.MailExam;
import member.service.MemberNotFoundException;
import member.service.SearchPwdService;
import mvc.command.CommandHandler;

public class SearchPwdHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/searchPwdForm.jsp";
	private SearchPwdService SearchPwdSvc = new SearchPwdService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if(req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}

}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException {
		String id = trim(req.getParameter("id"));
		String phone = trim(req.getParameter("phone"));
		
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		if(id==null || id.isEmpty())
			errors.put("id", Boolean.TRUE);
		if(phone==null || phone.isEmpty())
			errors.put("phone", Boolean.TRUE);
		
		if(!errors.isEmpty()){
			return FORM_VIEW;
		}
		
		try {
			Member tempMember = SearchPwdSvc.searchPwd(id,phone);
			MailExam.PasswordMail(tempMember);
			req.getSession().setAttribute("tempMember", tempMember);
			return "/WEB-INF/view/searchPwdSuccess.jsp";
		} catch (MemberNotFoundException e) {
			errors.put("idOrphoneNotMatch", Boolean.TRUE);
			return FORM_VIEW;
		}
	}

	private String trim(String str) {
		return str == null ? null : str.trim();
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) {
		
		return FORM_VIEW;
	}
}
