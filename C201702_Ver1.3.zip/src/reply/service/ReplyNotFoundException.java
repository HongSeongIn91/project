package reply.service;

public class ReplyNotFoundException extends Exception {

}
