package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import preview.service.ListPreviewService;
import preview.service.PreviewPage;
import movie.service.MovieData;
import movie.service.MovieNotFoundException;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;

public class ReadMovieHandler implements CommandHandler {

	private ReadMovieService readService = new ReadMovieService();
	private ListPreviewService listPreviewSvc = new ListPreviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		String noVal = req.getParameter("mv_num");
		int mv_num = Integer.parseInt(noVal);
		String Sort= req.getParameter("movieSort");
		String movietop = req.getParameter("movietop");
		String movieSort = "mv_reldate";
		if(Sort!=null){
			movieSort=Sort;
		}
		
		String prePageNoVal = req.getParameter("prePageNo");
		int pageNo = 1;
		if (prePageNoVal != null) {
			pageNo = Integer.parseInt(prePageNoVal);
			
		}
		
		try {
			//MovieData객체는 추후 기대평과 합치기위한 목적으로 남겨둔다
			MovieData movieData = readService.getMovie(mv_num, true);
			req.setAttribute("movieData", movieData);
			
			PreviewPage previewPage = listPreviewSvc.getPreviewPage(pageNo, mv_num);
			req.setAttribute("previewPage", previewPage);
			req.setAttribute("mv_num", mv_num);
			req.setAttribute("movieSort", movieSort);
			req.setAttribute("movietop", movietop);
			
			return "/WEB-INF/view/readMovie.jsp";
		} catch (MovieNotFoundException e) {
			req.getServletContext().log("no movie", e);
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

	
}
