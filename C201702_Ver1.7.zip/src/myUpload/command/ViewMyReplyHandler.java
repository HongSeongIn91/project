package myUpload.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import mvc.command.CommandHandler;
import myUpload.service.myReplyPage;
import reply.service.ListReplyService;


public class ViewMyReplyHandler implements CommandHandler {

	private ListReplyService listService = new ListReplyService();
	/*private ListService listService = new ListService();*/
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		User user = (User)req.getSession().getAttribute("authUser");
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		myReplyPage myReplyPage = listService.getMyReplyPage(user.getId(), pageNo);
		req.setAttribute("myReplyPage", myReplyPage);
		return "/WEB-INF/view/listMyReply.jsp";
	}

}
