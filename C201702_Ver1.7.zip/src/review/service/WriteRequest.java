package review.service;

import java.util.Map;

public class WriteRequest {

	
	private String rv_m_id;
	private int mv_num;
	private String rv_title;
	private String rvc_content;

	public WriteRequest(String rv_m_id, String rv_title, int mv_num, String rvc_content) {
		this.rv_m_id = rv_m_id;
		this.mv_num=mv_num;
		this.rv_title = rv_title;
		this.rvc_content = rvc_content;
	}

	public String getRv_content() {
		return rvc_content;
	}
	 
	public String getRv_m_id() {
		return rv_m_id;
	}

	public String getRv_title() {
		return rv_title;
	}

	public int getMv_num() {
		return mv_num;
	}

	public void setMv_num(int mv_num) {
		this.mv_num = mv_num;
	}
	
	public void validate(Map<String, Boolean> errors) { 
		if(rv_title == null || rv_title.trim().isEmpty()) { 
			errors.put("rv_title", Boolean.TRUE); 
		}
		
		if(rvc_content == null || rvc_content.trim().isEmpty()) {
			errors.put("rvc_content", Boolean.TRUE);
		} 
	}

}
