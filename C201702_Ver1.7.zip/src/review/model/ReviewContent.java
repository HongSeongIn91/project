package review.model;

public class ReviewContent {

	private Integer rvc_rv_num;
	private String rvc_content;
	
	public ReviewContent(Integer rvc_rv_num, String rvc_content) {
		super();
		this.rvc_rv_num = rvc_rv_num;
		this.rvc_content = rvc_content;
	}

	public Integer getRvc_rv_num() {
		return rvc_rv_num;
	}

	public String getRvc_content() {
		return rvc_content;
	}
	
}
