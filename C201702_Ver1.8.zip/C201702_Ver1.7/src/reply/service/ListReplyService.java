package reply.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import myUpload.service.myReply;
import myUpload.service.myReplyPage;
import Connection.DBConnection;
import reply.dao.ReplyDao;
import reply.model.Reply;

public class ListReplyService {

	private ReplyDao replyDao = new ReplyDao();
	private int size = 30;
	private int mySize = 5;

	public ReplyPage getReplyPage(int pageNo, int rv_num)
			throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {

			// 댓글 총 개수
			int total = replyDao.selectCount(conn, rv_num);
			System.out.println("total->" + total);

		
			int startRow = (pageNo - 1) * size + 1;
			List<Reply> reply = replyDao.select(conn, startRow, size, rv_num);

			return new ReplyPage(total, pageNo, size, reply);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}
	
	public myReplyPage getMyReplyPage(String m_id, int pageNo) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = replyDao.selectCountByMyId(conn, m_id);
			int startRow = (pageNo - 1) * mySize + 1;
			List<myReply> content = replyDao.selectByMyId(conn, startRow, mySize, m_id);
			return new myReplyPage(total, pageNo, mySize, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}


}
