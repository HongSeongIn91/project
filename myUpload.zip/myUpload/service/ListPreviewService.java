package myUpload.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import preview.model.Preview;
import myUpload.dao.PreviewDao;
import Connection.DBConnection;

public class ListPreviewService {

	private PreviewDao previewDao = new PreviewDao();
	private int size = 10;
	
	public PreviewPage getPreviewPage(String pre_m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = previewDao.selectCount(conn, pre_m_id);
			List<Preview> content = previewDao.select(conn, (pageNum-1)*size, size, pre_m_id);
			return new PreviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
