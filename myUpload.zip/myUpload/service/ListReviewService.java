package myUpload.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import review.model.Review;
import myUpload.dao.ReviewDao;
import Connection.DBConnection;

public class ListReviewService {

	private ReviewDao reviewDao = new ReviewDao();
	private int size = 10;
	
	public ReviewPage getReviewPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = reviewDao.selectCount(conn, m_id);
			List<Review> content = reviewDao.select(conn, (pageNum-1)*size, size, m_id);
			return new ReviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
