package myUpload.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import review.model.Review;
import member.dao.JdbcUtil;

public class ReviewDao {

	public int selectCount(Connection conn, String rv_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try{
			pstmt = conn.prepareStatement("select count(*) from review where rv_m_id = ?");
			pstmt.setString(1, rv_m_id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = rs.getInt(1);
				System.out.println("ReviewDao_rs.getInt(1):"+ rs.getInt(1));
				return result;
				
			} else {
				return result;
			}
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<Review> select(Connection conn, int startRow, int size, String rv_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT * FROM REVIEW WHERE RV_M_ID= ? ORDER BY RV_NUM DESC"
					+ ") A WHERE ROWNUM <= ?"
					+ ") WHERE RNUM >= ?"
					);
			
			pstmt.setString(1, rv_m_id);
			pstmt.setInt(2, startRow+size);
			pstmt.setInt(3, startRow);
			
			System.out.println("reviewDao_m_id:" +rv_m_id);
			System.out.println("reviewDao_startRow+size:"+startRow+size);
			System.out.println("reviewDao_startRow:" +startRow);
			
			rs = pstmt.executeQuery();
			List<Review> result = new ArrayList<Review>();
			while (rs.next()) {
				result.add(convertReview(rs));
			}
			return result;
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private Review convertReview(ResultSet rs) throws SQLException {

		return new Review(
				rs.getInt("rv_num"), 
				rs.getInt("rv_mv_num"),
				rs.getString("rv_m_id"),
				toDate(rs.getTimestamp("rv_regdate")),
				rs.getString("rv_title"),
				rs.getInt("rv_readcnt")
				);
	}

	private Date toDate(Timestamp timestamp) {
		
		return new Date(timestamp.getTime());
	}

}
