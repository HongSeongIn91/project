package reply.command;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import reply.dao.ReplyDao;
import reply.service.ListReplyService;
import reply.service.ModifyReplyService;
import reply.service.ReplyNotFoundException;
import reply.service.ReplyPage;
import review.service.ReadReviewService;
import review.service.ReadSearchReviewService;
import review.service.ReviewContentNotFoundException;
import review.service.ReviewData;
import review.service.ReviewNotFoundException;
import review.service.SearchReviewData;
import reply.service.ModifyReplyRequest;
import review.service.PermissionDeniedException;
import auth.service.User;
import mvc.command.CommandHandler;

public class ModifySearchReplyHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/modifysearchReplyForm.jsp";

	private ReadSearchReviewService readReviewSvc = new ReadSearchReviewService();
	private ModifyReplyService modifyReplySvc = new ModifyReplyService();
	private ListReplyService listReplySvc = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if (req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, ReviewContentNotFoundException, IOException {
		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String pageNo = req.getParameter("pageNo");//페이지번호
		String noVal = req.getParameter("rp_num");
		String noVal1 = req.getParameter("rp_rv_num");
		String noVal2 = req.getParameter("replyPageNo");
		String reviewSort = req.getParameter("reviewSort");
		String keyField = req.getParameter("keyField");
		String keyWord = req.getParameter("keyWord");
		
		int rp_num = Integer.parseInt(noVal);
		int rp_rv_num = Integer.parseInt(noVal1);
		int replyPageNo = 1;
		if(noVal2 != null) {
			replyPageNo = Integer.parseInt(noVal2); 
		}
		
		if(reviewSort==null){
			reviewSort="rv_num";
		}
		
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		
		try {
			ModifyReplyRequest modReq = new ModifyReplyRequest(authUser.getId(), rp_num, req.getParameter("content"), rp_rv_num, replyPageNo);
			
		
			modReq.validate(errors);
			if (!errors.isEmpty()) {
				return FORM_VIEW;
			}

			
			SearchReviewData searchReviewData = readReviewSvc.getReview(rp_rv_num, false);
				
			modifyReplySvc.modify(modReq);
			ReplyPage replyPage = listReplySvc.getReplyPage(replyPageNo, rp_rv_num);
			
			req.setAttribute("pageNo", pageNo);
			req.setAttribute("modReq", modReq);
			req.setAttribute("searchReviewData", searchReviewData);
			req.setAttribute("replyPage", replyPage);
			req.setAttribute("rp_rv_num", rp_rv_num);
			req.setAttribute("reviewSort", reviewSort);
			req.setAttribute("keyWord", keyWord);
			req.setAttribute("keyField", keyField);
			
			
			
			return "/WEB-INF/view/readSearchReview.jsp";
		} catch (ReviewNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		} catch (PermissionDeniedException e) {
			res.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) throws IOException, ClassNotFoundException, NamingException {
		
		String pageNo = req.getParameter("pageNo");//페이지번호
		String noVal = req.getParameter("rp_num");
		String noVal1 = req.getParameter("rp_rv_num");
		String noVal2 = req.getParameter("replypageNo");
		String reviewSort = req.getParameter("reviewSort");
		String keyField = req.getParameter("keyField");
		String keyWord = req.getParameter("keyWord");
		
		int rp_num = Integer.parseInt(noVal);
		
		if(reviewSort==null){
			reviewSort="rv_num";
		}
		int rp_rv_num = Integer.parseInt(noVal1);
		int replyPageNo = 1;
		if(noVal2 != null) {
			replyPageNo = Integer.parseInt(noVal2); 
		}
		
		
		try {
			SearchReviewData searchReviewData = readReviewSvc.getReview(rp_rv_num, false);
			req.setAttribute("searchReviewData", searchReviewData);
			req.setAttribute("pageNo", pageNo);
			req.setAttribute("rp_num", rp_num);
			req.setAttribute("rp_rv_num", rp_rv_num);
			req.setAttribute("replyPageNo", replyPageNo);
			req.setAttribute("reviewSort", reviewSort);
			req.setAttribute("keyWord", keyWord);
			req.setAttribute("keyField", keyField);
		} catch (ReviewNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ReviewContentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return FORM_VIEW;
		
		}
	}

