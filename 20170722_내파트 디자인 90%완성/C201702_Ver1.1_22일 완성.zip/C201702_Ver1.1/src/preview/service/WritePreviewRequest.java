package preview.service;

import java.util.Map;

public class WritePreviewRequest {

	private String pre_m_id;
	private String pre_content;
	private int pre_mv_num;
	
	public WritePreviewRequest(String pre_m_id, String pre_content,
			int pre_mv_num) {
		this.pre_m_id = pre_m_id;
		this.pre_content = pre_content;
		this.pre_mv_num = pre_mv_num;
	}

	public String getPre_m_id() {
		return pre_m_id;
	}

	public String getPre_content() {
		return pre_content;
	}

	public int getPre_mv_num() {
		return pre_mv_num;
	}

	public void validate(Map<String, Boolean> errors) {
		if(pre_content == null || pre_content.trim().isEmpty()) {
			errors.put("pre_content", Boolean.TRUE);
		}
		
	}
	
	
}
