package review.service;

public class ReviewNotFoundException extends Exception {

}
