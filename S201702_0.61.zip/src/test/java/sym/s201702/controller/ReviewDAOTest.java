package sym.s201702.controller;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import sym.s201702.DAO.ReviewDAO;
import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReviewVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations ={"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})

public class ReviewDAOTest {

	private static final Logger logger = LoggerFactory.getLogger(ReviewDAOTest.class);
	
	@Inject
	private ReviewDAO dao;
	
	@Test
	public void testListCriteria() throws Exception {
		
		Criteria cri = new Criteria();
		cri.setPage(2);
		cri.setPerPageNum(10);
		
		List<ReviewVO> list = dao.listCriteria(cri);
		
		for (ReviewVO reviewVO : list) {
			logger.info(reviewVO.getRv_num() + ":" + reviewVO.getRv_title());
		}
	}
}
