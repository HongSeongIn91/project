package sym.s201702.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.MovieDAO;
import sym.s201702.domain.MovieVO;

@Service
public class MovieServiceImpl implements MovieService {

	@Inject
	private MovieDAO dao;
	
	@Override
	public List<MovieVO> getMovieTitle() throws Exception {
		
		return dao.relSelect();
	}

}
