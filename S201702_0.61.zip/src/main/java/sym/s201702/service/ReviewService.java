package sym.s201702.service;

import java.util.List;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReviewData;
import sym.s201702.domain.ReviewVO;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

public interface ReviewService {

	public void regist(WriteReviewDTO dto) throws Exception;
	
	public ReviewData read(Integer rv_num) throws Exception;
	
	public void modify(ModifyReviewDTO dto) throws Exception;
	
	public void remove(Integer rv_num) throws Exception;
	
	public List<ReviewVO> listCriteria(Criteria cri) throws Exception;

	public int listCountCriteria(Criteria cri) throws Exception;
	
	public List<ReviewVO> listSearchCriteria(SearchCriteria cri) throws Exception;
	
	public int listSearchCount(SearchCriteria cri) throws Exception;
	
}
