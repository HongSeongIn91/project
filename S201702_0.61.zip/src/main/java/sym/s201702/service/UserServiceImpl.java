package sym.s201702.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.UserDAO;
import sym.s201702.domain.UserVO;
import sym.s201702.dto.LoginDTO;

@Service
public class UserServiceImpl implements UserService {

	@Inject
	private UserDAO dao;
	
	@Override
	public UserVO login(LoginDTO dto) throws Exception {
		
		return dao.login(dto);
	}

}
