package sym.s201702.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.MemberDAO;
import sym.s201702.domain.MemberVO;
import sym.s201702.dto.ChangeMemberDTO;
import sym.s201702.dto.MemberDTO;
import sym.s201702.exception.DuplicateIdException;
import sym.s201702.exception.InvalidPasswordException;
import sym.s201702.exception.NotMatchConfirmPasswordException;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO dao;
	
	@Override
	public void join(MemberDTO dto) throws Exception {
		
		MemberVO vo = dao.selectById(dto.getM_id());
		
		if (vo != null) {
			throw new DuplicateIdException();
		}
		
		dao.insert(dto);

	}

	@Override
	public void checkPwd(MemberDTO dto) throws Exception {
		
		MemberVO vo = dao.selectById(dto.getM_id());
		String pwd = dto.getM_pw();
		
		if (!vo.getM_pw().equals(pwd)) {
			throw new InvalidPasswordException();
		}
		
	}

	@Override
	public void changeMemberInfo(ChangeMemberDTO dto) throws Exception {
		
		MemberVO vo = dao.selectById(dto.getM_id());
		
		if (!matchPassword(dto.getNewPwd(), dto.getConfirmPassword())) {
			throw new NotMatchConfirmPasswordException();
		}
		
		vo.changePassword(dto.getNewPwd());
		vo.changeEmail(dto.getNewEmail());
		vo.changePhone(dto.getNewPhone());
		
		dao.update(vo);
		
	}

	private boolean matchPassword(String newPwd, String confirmPassword) {
		
		return confirmPassword.equals(newPwd);
	}

	@Override
	public void withdraw(MemberDTO dto) throws Exception {
		
		dao.delete(dto);
	}

}
