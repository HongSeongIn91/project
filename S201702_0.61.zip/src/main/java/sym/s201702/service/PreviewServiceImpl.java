package sym.s201702.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.PreviewDAO;
import sym.s201702.domain.Criteria;
import sym.s201702.domain.PreviewVO;

@Service
public class PreviewServiceImpl implements PreviewService {

	@Inject
	private PreviewDAO dao;
	
	@Override
	public List<PreviewVO> myPreview(Criteria cri) throws Exception {
		return dao.myPreview(cri);
	}

}
