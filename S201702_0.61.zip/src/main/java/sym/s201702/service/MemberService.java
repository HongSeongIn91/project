package sym.s201702.service;

import sym.s201702.domain.MemberVO;
import sym.s201702.dto.ChangeMemberDTO;
import sym.s201702.dto.MemberDTO;

public interface MemberService {

	public void join(MemberDTO member) throws Exception;

	public void checkPwd(MemberDTO dto) throws Exception;

	public void changeMemberInfo(ChangeMemberDTO dto) throws Exception;

	public void withdraw(MemberDTO dto) throws Exception;

	
}
