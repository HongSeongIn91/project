package sym.s201702.service;

import java.util.List;

import sym.s201702.domain.MovieVO;

public interface MovieService {

	public List<MovieVO> getMovieTitle() throws Exception;
	
}
