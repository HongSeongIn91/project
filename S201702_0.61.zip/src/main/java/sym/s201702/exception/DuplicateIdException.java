package sym.s201702.exception;

public class DuplicateIdException extends Exception {

}
