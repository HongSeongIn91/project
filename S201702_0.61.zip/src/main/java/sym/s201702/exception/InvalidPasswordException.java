package sym.s201702.exception;

public class InvalidPasswordException extends RuntimeException {

}
