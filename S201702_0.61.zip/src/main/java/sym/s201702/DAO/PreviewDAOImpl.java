package sym.s201702.DAO;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.PreviewVO;

@Repository
public class PreviewDAOImpl implements PreviewDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "sym.s201702.mapper.PreviewMapper";
	
	@Override
	public List<PreviewVO> myPreview(Criteria cri) {
		return session.selectList(namespace + ".myPreview", cri);
	}

}
