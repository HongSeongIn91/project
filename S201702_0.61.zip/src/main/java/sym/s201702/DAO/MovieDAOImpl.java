package sym.s201702.DAO;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.MovieVO;

@Repository
public class MovieDAOImpl implements MovieDAO {

	@Inject
	private SqlSession sqlSession;
	
	private static final String namespace = "sym.s201702.mapper.MovieMapper";

	@Override
	public List<MovieVO> relSelect() throws Exception {
		
		return sqlSession.selectList(namespace+".relSelect");
	}
	
	
}
