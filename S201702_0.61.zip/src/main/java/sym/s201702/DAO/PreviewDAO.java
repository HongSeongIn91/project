package sym.s201702.DAO;

import java.util.List;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.PreviewVO;

public interface PreviewDAO {
	
	public List<PreviewVO> myPreview(Criteria cri);
	

}
