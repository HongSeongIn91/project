package sym.s201702.DAO;

import sym.s201702.domain.MemberVO;
import sym.s201702.dto.MemberDTO;

public interface MemberDAO {

	public String getTime();
	
	public void insert(MemberDTO dto);

	public MemberVO selectById(String m_id);

	public void update(MemberVO vo);

	public void delete(MemberDTO dto);
	
}
