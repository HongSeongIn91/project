package sym.s201702.DAO;

import sym.s201702.domain.UserVO;
import sym.s201702.dto.LoginDTO;

public interface UserDAO {

	public UserVO login(LoginDTO dto) throws Exception;
	
}
