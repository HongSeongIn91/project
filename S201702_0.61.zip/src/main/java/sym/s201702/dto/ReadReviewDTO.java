package sym.s201702.dto;

public class ReadReviewDTO {
	
	private int mv_num;
	private String mv_title;
	private String rv_title;
	private String rv_regdate;
	private int rv_readcnt;
	
	
	public int getMv_num() {
		return mv_num;
	}
	public void setMv_num(int mv_num) {
		this.mv_num = mv_num;
	}
	public String getMv_title() {
		return mv_title;
	}
	public void setMv_title(String mv_title) {
		this.mv_title = mv_title;
	}
	public String getRv_title() {
		return rv_title;
	}
	public void setRv_title(String rv_title) {
		this.rv_title = rv_title;
	}
	public String getRv_regdate() {
		return rv_regdate;
	}
	public void setRv_regdate(String rv_regdate) {
		this.rv_regdate = rv_regdate;
	}
	public int getRv_readcnt() {
		return rv_readcnt;
	}
	public void setRv_readcnt(int rv_readcnt) {
		this.rv_readcnt = rv_readcnt;
	}
	
}
