package sym.s201702.domain;

public class ReviewData {

	private ReviewVO review;
	private ReviewContentVO content;
	
	public ReviewData(ReviewVO review, ReviewContentVO content) {
		super();
		this.review = review;
		this.content = content;
	}

	public ReviewVO getReview() {
		return review;
	}

	public String getContent() {
		return content.getRvc_content();
	}
	
}
