package sym.s201702.domain;

import java.util.Date;

public class MovieVO {

	private int mv_num;
	private String mv_title;
	private String mv_summary;
	private Date mv_reldate;
	private String mv_time;
	private String mv_rating;
	private String mv_director;
	private String mv_actor;
	private int mv_readcnt;
	private String mv_poster;
	
	public int getMv_num() {
		return mv_num;
	}
	public void setMv_num(int mv_num) {
		this.mv_num = mv_num;
	}
	public String getMv_title() {
		return mv_title;
	}
	public void setMv_title(String mv_title) {
		this.mv_title = mv_title;
	}
	public String getMv_summary() {
		return mv_summary;
	}
	public void setMv_summary(String mv_summary) {
		this.mv_summary = mv_summary;
	}
	public Date getMv_reldate() {
		return mv_reldate;
	}
	public void setMv_reldate(Date mv_reldate) {
		this.mv_reldate = mv_reldate;
	}
	public String getMv_time() {
		return mv_time;
	}
	public void setMv_time(String mv_time) {
		this.mv_time = mv_time;
	}
	public String getMv_rating() {
		return mv_rating;
	}
	public void setMv_rating(String mv_rating) {
		this.mv_rating = mv_rating;
	}
	public String getMv_director() {
		return mv_director;
	}
	public void setMv_director(String mv_director) {
		this.mv_director = mv_director;
	}
	public String getMv_actor() {
		return mv_actor;
	}
	public void setMv_actor(String mv_actor) {
		this.mv_actor = mv_actor;
	}
	public int getMv_readcnt() {
		return mv_readcnt;
	}
	public void setMv_readcnt(int mv_readcnt) {
		this.mv_readcnt = mv_readcnt;
	}
	public String getMv_poster() {
		return mv_poster;
	}
	public void setMv_poster(String mv_poster) {
		this.mv_poster = mv_poster;
	}
	
}
