package sym.s201702.domain;

import java.util.Date;

public class PreviewVO {

	private Integer pre_num;
	private Integer pre_mv_num;
	private String pre_m_id;
	private Date pre_regdate;
	private String pre_content;
	
	
	public Integer getPre_num() {
		return pre_num;
	}
	public void setPre_num(Integer pre_num) {
		this.pre_num = pre_num;
	}
	public Integer getPre_mv_num() {
		return pre_mv_num;
	}
	public void setPre_mv_num(Integer pre_mv_num) {
		this.pre_mv_num = pre_mv_num;
	}
	public String getPre_m_id() {
		return pre_m_id;
	}
	public void setPre_m_id(String pre_m_id) {
		this.pre_m_id = pre_m_id;
	}
	public Date getPre_regdate() {
		return pre_regdate;
	}
	public void setPre_regdate(Date pre_regdate) {
		this.pre_regdate = pre_regdate;
	}
	public String getPre_content() {
		return pre_content;
	}
	public void setPre_content(String pre_content) {
		this.pre_content = pre_content;
	}
	
	
	
	
}
