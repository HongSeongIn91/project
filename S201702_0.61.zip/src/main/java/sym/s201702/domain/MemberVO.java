package sym.s201702.domain;

import java.util.Date;

public class MemberVO {

	private String m_id;
	private String m_pw;
	private String m_birth;
	private String m_gender;
	private String m_email;
	private String m_phone;
	private Date m_regDate;
	
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}
	public String getM_birth() {
		return m_birth;
	}
	public void setM_birth(String m_birth) {
		this.m_birth = m_birth;
	}
	public String getM_gender() {
		return m_gender;
	}
	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}
	public String getM_email() {
		return m_email;
	}
	public void setM_email(String m_email) {
		this.m_email = m_email;
	}
	public String getM_phone() {
		return m_phone;
	}
	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}
	public Date getM_regDate() {
		return m_regDate;
	}
	public void setM_regDate(Date m_regDate) {
		this.m_regDate = m_regDate;
	}
	
	public void changePassword(String newPwd) {
		this.m_pw = newPwd;
	}
	public void changeEmail(String newEmail) {
		this.m_email = newEmail;
	}
	public void changePhone(String newPhone) {
		this.m_phone = newPhone;
	}
}
