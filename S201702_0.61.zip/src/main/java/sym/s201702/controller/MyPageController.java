package sym.s201702.controller;



import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.PageMaker;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.service.PreviewService;
import sym.s201702.service.ReplyService;
import sym.s201702.service.ReviewService;

@Controller
@RequestMapping(value = "/myPage/*")
public class MyPageController {

	private static final Logger logger = LoggerFactory.getLogger(MyPageController.class);
	
	@Inject
	private ReviewService review;
	
	@Inject
	private ReplyService reply;
	
	@Inject
	private PreviewService preview;
	
	
	
	@RequestMapping(value = "/myReview", method = RequestMethod.GET)
	public void myReview(@ModelAttribute("cri") SearchCriteria cri, Model model) throws Exception {
		
		logger.info("********************* list myReview GET ***********************");
		logger.info(cri.toString());
		
		model.addAttribute("myReview", review.listCriteria(cri));
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(review.listCountCriteria(cri));
		
		model.addAttribute("pageMaker", pageMaker);
		
	}
	

	@RequestMapping(value = "/myReply", method = RequestMethod.GET)
	public void myReply(@ModelAttribute("cri") Criteria cri, Model model) throws Exception {
		
		logger.info("********************* list myReply GET ***********************");
		logger.info(cri.toString());
		
		model.addAttribute("myReply", reply.myReply(cri));
		
	}
	
	@RequestMapping(value = "/myPreview",method = RequestMethod.GET)
	public void myPreview(@ModelAttribute("cri") Criteria cri,Model model) throws Exception {
		
		logger.info("********************* list myPreview GET ***********************");
		logger.info(cri.toString());
		
		model.addAttribute("myPreview", preview.myPreview(cri));
		
		
		
	}
	
	

	
	
	
	
	
	
}

