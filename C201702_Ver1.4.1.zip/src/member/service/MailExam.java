package member.service;

import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import member.model.Member;

public class MailExam {

	public static void PasswordMail(Member tempMember) {
		try {
			new MailExam(tempMember);
		} catch (Exception e) {
			System.out.println("error");
			System.out.println(e.getMessage());
		}
	}
	
	public MailExam(Member tempMember) throws AddressException, MessagingException {
		
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.host", "smtp.gmail.com");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.quitwait", "false");
		
		Authenticator auth = new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("hinn0208@gmail.com", "ghdtjddls2");
			}
		};
		
		Session session = Session.getDefaultInstance(props, auth);
		
		MimeMessage message = new MimeMessage(session);
		// 보내는 사람을 hinn0208@gmail.com 말고 다른 걸로 변경. 예를 들어 SYM.
		message.setSender(new InternetAddress("hinn0208@gmail.com"));
		message.setSubject("test");
		
		message.setRecipient(Message.RecipientType.TO, new InternetAddress(tempMember.getM_email())); 
		// 비밀번호 찾으려는 사용자의 메일주소 사용
		
		Multipart mp = new MimeMultipart();
		MimeBodyPart mbp1 = new MimeBodyPart();
		mbp1.setText(tempMember.getM_pw());
		// 임시로 생성된 비밀번호를 담으면 됨
		mp.addBodyPart(mbp1);
		
		MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap();
		mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		CommandMap.setDefaultCommandMap(mc);
		
		message.setContent(mp);
		
		Transport.send(message);
	}

}
