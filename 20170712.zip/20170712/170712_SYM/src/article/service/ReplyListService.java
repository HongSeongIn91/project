package article.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.dao.ReplyDao;
import article.model.Reply;

public class ReplyListService {
	
	private ReplyDao replyDao = new ReplyDao();
	private int size = 10;
	
	public ReplyPage getListPage(int pageNum, int articleNum) throws ClassNotFoundException, NamingException {
		
		
		try (Connection conn = DBConnection.getConnection()) {
			int total = replyDao.selectCount(conn,articleNum);
			List<Reply> reply = replyDao.select(conn,articleNum);
			return new ReplyPage(total, pageNum, size, reply);
		} catch (SQLException e) {
			 throw new RuntimeException(e);
		}
	}
	

}
