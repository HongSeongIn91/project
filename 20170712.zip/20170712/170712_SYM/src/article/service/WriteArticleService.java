package article.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import Connection.DBConnection;
import article.dao.ArticleContentDao;
import article.dao.ArticleDao;
import article.model.Article;
import article.model.ArticleContent;

public class WriteArticleService {

	private ArticleDao articleDao = new ArticleDao();
	private ArticleContentDao contentDao = new ArticleContentDao();
	
	//사용자의 넘겨진 정보를 받아
	public Integer write(WriteRequest req) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			//id,content,title을 갖고 전체 게시글에대한 정보를 생성하러감
			//등록일 카운트 등등
			Article article = toArticle(req);
			
			//넘겨와진정보를 담아 내용빼고담아 insert
			Article savedArticle = articleDao.insert(conn, article);
			if(savedArticle == null) {
				throw new RuntimeException("fail to insert article");
			}
			
			//글제목과 내용을 담아 insert
			ArticleContent content = new ArticleContent(
					savedArticle.getRv_num(), req.getRv_content());
			ArticleContent savedContent = contentDao.insert(conn, content);
			
			if(savedContent == null) {
				throw new RuntimeException("fail to insert article_content");
			}
			
			conn.commit();
			
			return savedArticle.getRv_num();//글번호 리턴
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (RuntimeException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

	//작성자, 제목, 내용 받아와서 날짜정보를 추가함
	//영화제목을같이 담아야함
	//일단임의로 1을 담음
	private Article toArticle(WriteRequest req) {
		Date now = new Date();
		//return new Article(null, 1 ,req.getWriter(), now,req.getRv_title(), 0);

		return new Article(null, 1 ,req.getRv_m_id(), now,req.getRv_title(), 0);
	}
}
