package article.service;

import article.dao.ReplyDao;

public class ReplyService {
	private ReplyDao replyDao = new ReplyDao();
	

}
