package article.service;

import java.util.Map;

public class DeleteRequest {
	
	private String userId;
	private int articleNumber;
	
	public DeleteRequest(String userId, int articleNumber) {
		this.userId = userId;
		this.articleNumber = articleNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getArticleNumber() {
		return articleNumber;
	}

	public void setArticleNumber(int articleNumber) {
		this.articleNumber = articleNumber;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(userId == null || userId.trim().isEmpty()) {
			errors.put("userId", Boolean.TRUE);
		}
	}
}
