package article.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.dao.ReplyDao;
import article.model.Reply;
import member.dao.JdbcUtil;

public class DeleteReplyService {

	private ReplyDao replyDao = new ReplyDao();

	public void delete(DeleteReplyRequest delReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);

			replyDao.delete(conn, delReq.getReplyNumber());

			conn.commit();
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}

	}

}
