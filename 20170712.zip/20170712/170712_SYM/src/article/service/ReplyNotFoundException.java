package article.service;

public class ReplyNotFoundException extends RuntimeException {

}
