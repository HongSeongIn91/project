package article.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.model.Reply;
import article.service.ArticleContentNotFoundException;
import article.service.ArticleData;
import article.service.ArticleNotFoundException;
import article.service.ReadArticleService;
import article.service.ReplyListService;
import article.service.ReplyPage;
import mvc.command.CommandHandler;

public class ReadArticleHandler implements CommandHandler {

	private ReadArticleService readService = new ReadArticleService();
	private ReplyListService replyService= new ReplyListService();
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		String noVal = req.getParameter("no");
		int articleNum = Integer.parseInt(noVal);
		
		try {
			//readService는 두 내용을 합친다
			ArticleData articleData = readService.getArticle(articleNum, true);
			req.setAttribute("articleData", articleData);
			
		
			String repageNoVal = req.getParameter("replypageNo");
			int pageNo = 1;
					
			//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
			if(repageNoVal != null) {
				pageNo = Integer.parseInt(repageNoVal);
			}
			
			ReplyPage replyPage = replyService.getListPage(pageNo, articleNum);
			req.setAttribute("replyPage", replyPage);
			req.setAttribute("articleNum", articleNum);
			
			//값을 가져와서 articleData객체에담아 readArticle.jsp로감
			return "/WEB-INF/view/readArticle.jsp";
		} catch (ArticleNotFoundException | ArticleContentNotFoundException e) {
			req.getServletContext().log("no article", e);
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

}
