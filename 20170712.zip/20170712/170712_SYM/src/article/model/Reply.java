package article.model;
import java.sql.Timestamp;
import java.util.Date;

public class Reply {
		private Integer rp_num;
		private int rp_rv_num;
		private String rp_m_id;
		private Date rp_regdate;
		private String rp_content;
		
		public Reply(Integer rp_num, int rp_rv_num, String rp_m_id, Date rp_regdate, String rp_content) {
			this.rp_num = rp_num;
			this.rp_rv_num = rp_rv_num;
			this.rp_m_id = rp_m_id;
			this.rp_regdate = rp_regdate;
			this.rp_content = rp_content;
		}

		public Integer getRp_num() {
			return rp_num;
		}
		public void setRp_num(Integer rp_num) {
			this.rp_num = rp_num;
		}
		public int getRp_rv_num() {
			return rp_rv_num;
		}
		public void setRp_rv_num(int rp_rv_num) {
			this.rp_rv_num = rp_rv_num;
		}
		public String getRp_m_id() {
			return rp_m_id;
		}
		public void setRp_m_id(String rp_m_id) {
			this.rp_m_id = rp_m_id;
		}
		public Date getRp_regdate() {
			return rp_regdate;
		}
		public void setRp_regdate(Timestamp rp_regdate) {
			this.rp_regdate = rp_regdate;
		}
		public String getRp_content() {
			return rp_content;
		}
		public void setRp_content(String rp_content) {
			this.rp_content = rp_content;
		}
		
		
		
}
