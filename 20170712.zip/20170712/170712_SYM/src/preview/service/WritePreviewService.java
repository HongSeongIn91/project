package preview.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import preview.dao.PreviewDao;
import preview.model.Preview;

public class WritePreviewService {

	private PreviewDao preDao = new PreviewDao();

	public Integer write(WritePreviewRequest req) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);

			Preview preview = toPreview(req);

			Preview savedPreview = preDao.insert(conn, preview);
			if (savedPreview == null) {
				throw new RuntimeException("fail to insert article");
			}

			conn.commit();
			return savedPreview.getPre_mv_num();

		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (RuntimeException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

	private Preview toPreview(WritePreviewRequest req) {
		Date now = new Date();
		//public Preview(Integer pre_num, int pre_mv_num, String pre_m_id, Date pre_regdate, String pre_content) {
		return new Preview(null, req.getPre_mv_num(), req.getPre_m_id(), now, req.getPre_content());
	}

}
