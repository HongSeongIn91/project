package preview.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import Connection.DBConnection;
import preview.dao.PreviewDao;
import preview.model.Preview;

public class PreviewListService {
	
	private PreviewDao preDao = new PreviewDao();
	private int size = 10;
	
	public PreviewPage getListPage(int pageNum, int previewNum) throws ClassNotFoundException, NamingException {

		
		try (Connection conn = DBConnection.getConnection()) {
			int total = preDao.selectCount(conn, previewNum);
			List<Preview> preList = preDao.select(conn, previewNum);
			return new PreviewPage(total, pageNum, size, preList);
		} catch (SQLException e) {
			 throw new RuntimeException(e);
		}
		
	}

}
