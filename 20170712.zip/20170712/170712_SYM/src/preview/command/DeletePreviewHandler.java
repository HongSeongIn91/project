package preview.command;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ReplyNotFoundException;
import auth.service.User;
import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;
import preview.service.DeletePreviewRequest;
import preview.service.DeletePreviewService;
import preview.service.PreviewListService;
import preview.service.PreviewPage;

public class DeletePreviewHandler implements CommandHandler{
	private static final String FORM_VIEW = "/WEB-INF/view/deletePreviewForm.jsp";
	
	private ReadMovieService readService = new ReadMovieService();
	private DeletePreviewService preService = new DeletePreviewService();
	private PreviewListService listService = new PreviewListService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}
	
	private String processForm(HttpServletRequest req, HttpServletResponse res) throws IOException, ClassNotFoundException, NamingException {
		try {
			String noVal = req.getParameter("preNo");		// 기대평 번호
			int preNo = Integer.parseInt(noVal);
			String noVal1 = req.getParameter("movieNo");		// 영화 정보 번호
			int movieNo = Integer.parseInt(noVal1);		
			String noVal2 = req.getParameter("prePageNo");		// 기대평 페이지 번호
			int prePageNo = 1;
			//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
			if(noVal2 != null) {
				prePageNo = Integer.parseInt(noVal2);
			}

			req.setAttribute("preNo", preNo);		// 댓글 번호
			req.setAttribute("movieNo", movieNo);		// 감상평 번호
			req.setAttribute("prePageNo", prePageNo);		// 댓글 페이지 번호
			
			return FORM_VIEW;
		}catch (ReplyNotFoundException e) {
			 res.sendError(HttpServletResponse.SC_NOT_FOUND);
			 return null;
		}
	}
	
	
	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws IOException, ClassNotFoundException, NamingException, SQLException {
		
		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String noVal = req.getParameter("preNo");		// 기대평 번호
		int preNo = Integer.parseInt(noVal);
		String noVal1 = req.getParameter("movieNo");		// 영화 정보 번호
		int movieNo = Integer.parseInt(noVal1);		
		String noVal2 = req.getParameter("prePageNo");		// 기대평 페이지 번호
		int prePageNo = 1;
		//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(noVal2 != null) {
			prePageNo = Integer.parseInt(noVal2);
		}
		

	
	DeletePreviewRequest delReq = new DeletePreviewRequest(authUser.getId(), preNo, movieNo, prePageNo);
	req.setAttribute("delReq", delReq);

	
	
	try {
			preService.delete(delReq);
			
			MovieData movieData = readService.getArticle(movieNo, false);
			req.setAttribute("movieData", movieData);
			
			PreviewPage prePage = listService.getListPage(prePageNo, movieNo);
			req.setAttribute("prePage", prePage);
			
	
	return "/WEB-INF/view/readMovie.jsp";
	}catch (ReplyNotFoundException e) {
		res.sendError(HttpServletResponse.SC_NOT_FOUND);
		return null;
	}
}
}
