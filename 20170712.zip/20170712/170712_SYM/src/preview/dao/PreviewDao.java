package preview.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import member.dao.JdbcUtil;
import preview.model.Preview;

public class PreviewDao {
	
	// 기대평 쓰기
	public Preview insert(Connection conn, Preview preview) throws SQLException {
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement("insert into preview (pre_num, pre_mv_num, pre_m_id, pre_regdate, pre_content) values (preview_sequence.nextval,?,?,?,?)");
			System.out.println("? : " + preview.getPre_regdate());
			pstmt.setInt(1, preview.getPre_mv_num());
			pstmt.setString(2, preview.getPre_m_id());
			pstmt.setTimestamp(3, toTimestamp(preview.getPre_regdate()));
			pstmt.setString(4, preview.getPre_content());
			
			System.out.println("preview.getPre_mv_num() -> " + preview.getPre_mv_num());
			System.out.println("preview.getPre_m_id() -> " + preview.getPre_m_id());
			System.out.println("프리뷰 1) preview.getPre_regdate() -> " + preview.getPre_regdate());
			
			int insertedCount = pstmt.executeUpdate();
			
		
			if(insertedCount > 0) {
				stmt = conn.createStatement();
				rs = stmt.executeQuery("select preview_sequence.currval from preview");
				
				if(rs.next()) {
					Integer newNum = rs.getInt(1);
					
					return new Preview(newNum, preview.getPre_mv_num(), preview.getPre_m_id(), preview.getPre_regdate(), preview.getPre_content());
				}
			}
			return null;
		}finally{
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
			JdbcUtil.close(pstmt);
		}
	}
	
	private Timestamp toTimestamp(Date date) {
		return new Timestamp(date.getTime());
	}
	
	public int selectCount(Connection conn, int pre_num) throws SQLException {
		
		PreparedStatement pstmt = null;
	
		ResultSet rs = null;
		
		try {
			
			pstmt = conn.prepareStatement("select count(*) from preview where pre_mv_num = ?");
			pstmt.setInt(1,pre_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				return rs.getInt(1);
			} return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
	
	private static Preview convertReply(ResultSet rs) throws SQLException {
		return new Preview(rs.getInt("pre_num"),
										rs.getInt("pre_mv_num"), 
										rs.getString("pre_m_id"), 
										toDate(rs.getTimestamp("pre_regdate")), 
										rs.getString("pre_content"));
	}
	
	public static Date toDate(Timestamp timestamp) {
		return new Date(timestamp.getTime());
	}
	
	
	public Preview selectById(Connection conn, int no) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select * from preview where pre_mv_num = ?");
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			Preview preview = null;
			if(rs.next()) {
				preview = convertReply(rs);
			}
			return preview;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
	
	// 댓글 수정
	public int update(Connection conn, int no, String content) throws SQLException {
		try(PreparedStatement pstmt = conn.prepareStatement("update preview set pre_content = ? where pre_num = ?")) {
			pstmt.setString(1, content);
			pstmt.setInt(2, no);
			return pstmt.executeUpdate();
		}
	}
	
	// 댓글 삭제
	public int delete(Connection conn, int no) throws SQLException {
		try(PreparedStatement pstmt = conn.prepareStatement("delete from preview where pre_num = ?")) {
			pstmt.setInt(1, no);
			return pstmt.executeUpdate();
		}
	}

	public List<Preview> select(Connection conn, int movieNum) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		
			pstmt = conn.prepareStatement("select * from preview, movie_info where preview.pre_mv_num = movie_info.mv_num and preview.pre_mv_num = ? order by pre_num	");
			pstmt.setInt(1, movieNum);
			rs = pstmt.executeQuery();
			
			List<Preview> preList = new ArrayList<Preview>();
			while(rs.next()) {
				preList.add(convertReply(rs));
			}
			return preList;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}		
	}
	
}
