package preview.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import review.service.PermissionDeniedException;
import Connection.DBConnection;
import preview.dao.PreviewDao;

public class DeletePreviewService {

	private PreviewDao preDao = new PreviewDao();

	public void delete(DeletePreviewRequest delPreReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			preDao.delete(conn, delPreReq.getPre_num());
			
			conn.commit();
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}
	
	
}
