package myUpload.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import mvc.command.CommandHandler;
import myUpload.service.ListService;
import preview.service.PreviewPage;


public class ViewMyPreviewHandler implements CommandHandler {

	/*private ListPreviewService listService = new ListPreviewService();*/
	private ListService listService = new ListService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		User user = (User)req.getSession().getAttribute("authUser");
		/*System.out.println(user.getId());*/
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		System.out.println(pageNo);
		PreviewPage previewPage = listService.getPreviewPage(user.getId(), pageNo);
		req.setAttribute("previewPage", previewPage);
		return "/WEB-INF/view/listMyPreview.jsp";
	}

}
