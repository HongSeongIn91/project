package reply.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import reply.service.ListReplyService;
import reply.service.ReplyPage;
import reply.service.WriteReplyRequest;
import reply.service.WriteReplyService;
import review.service.ReadReviewService;
import review.service.ReviewData;
import util.Token;
import auth.service.User;
import mvc.command.CommandHandler;

public class WriteReplyHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/readReview.jsp";
	private WriteReplyService writeReplySvc = new WriteReplyService();
	private ReadReviewService readReviewSvc = new ReadReviewService();
	private ListReplyService listReplySvc = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		if(Token.isValid(req)) {
		    Token.set(req);
		    req.setAttribute("TOKEN_SAVE_CHECK", "TRUE");
		} else {
			req.setAttribute("TOKEN_SAVE_CHECK", "FALSE");
		}

		if ("TRUE".equals(req.getAttribute("TOKEN_SAVE_CHECK"))) {

			User user = (User)req.getSession(false).getAttribute("authUser");
			
			Map<String, Boolean> errors = new HashMap<String, Boolean>();
			req.setAttribute("errors", errors);
			
			String noVal = req.getParameter("rp_rv_num");
			int rp_rv_num = Integer.parseInt(noVal);
			String reviewSort = req.getParameter("reviewSort");//소팅
			String pageNo = req.getParameter("pageNo");//페이지번호
			
			if(reviewSort==null){
				reviewSort="rv_num";
			}
			
			int replyPageNo = 1;
			
			WriteReplyRequest writeReplyReq = createWriteReplyRequest(user, req);
			writeReplyReq.validate(errors);
			
			if(!errors.isEmpty()) {
				return FORM_VIEW;
			}
			
			int newRp_num = writeReplySvc.write(writeReplyReq);
			ReviewData reviewData = readReviewSvc.getReview(rp_rv_num, false);
			ReplyPage replyPage = listReplySvc.getReplyPage(replyPageNo, rp_rv_num);
			
			req.setAttribute("newRp_num", newRp_num);
			req.setAttribute("reviewData", reviewData);
			req.setAttribute("replyPage", replyPage);
			req.setAttribute("reviewSort", reviewSort);
			req.setAttribute("pageNo", pageNo);
			
			return FORM_VIEW;
		} else {		
			res.sendRedirect(req.getContextPath()+"/reviewlist.do");
			return null;
		}
	}

	private WriteReplyRequest createWriteReplyRequest(User user,
			HttpServletRequest req) {
	
		return new WriteReplyRequest(
				user.getId(),
				req.getParameter("content"),
				Integer.parseInt(req.getParameter("rp_rv_num"))
				);
		
	}

}
