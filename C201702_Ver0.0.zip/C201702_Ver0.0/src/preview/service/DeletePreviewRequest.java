package preview.service;

public class DeletePreviewRequest {

	private String userId;
	private int pre_num;
	private int mv_num;
	private int prePageNo;
	
	public DeletePreviewRequest(String userId, int pre_num, int mv_num,
			int prePageNo) {
	
		this.userId = userId;
		this.pre_num = pre_num;
		this.mv_num = mv_num;
		this.prePageNo = prePageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getPre_num() {
		return pre_num;
	}

	public int getMv_num() {
		return mv_num;
	}

	public int getPrePageNo() {
		return prePageNo;
	}
	
	
}
