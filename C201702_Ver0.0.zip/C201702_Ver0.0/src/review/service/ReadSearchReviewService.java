package review.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import review.dao.ReviewContentDao;
import review.dao.ReviewDao;
import review.model.Review;
import review.model.ReviewContent;
import Connection.DBConnection;

public class ReadSearchReviewService {

	private ReviewDao reviewDao = new ReviewDao();
	private ReviewContentDao contentDao = new ReviewContentDao();
	
	public SearchReviewData getReview(int rv_num, boolean increaseReadcnt) throws ClassNotFoundException, NamingException, ReviewNotFoundException, ReviewContentNotFoundException {
		
		try (Connection conn = DBConnection.getConnection()) {
			Review review = reviewDao.selectByRvNum(conn, rv_num);
			if (review == null) {
				throw new ReviewNotFoundException();
			}
			
			ReviewContent content = contentDao.selectByRvNum(conn, rv_num);
			if (content == null) {
				throw new ReviewContentNotFoundException();
			}
			
			if (increaseReadcnt) {
				reviewDao.increaseReadcnt(conn, rv_num);
			}
			return new SearchReviewData(review, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}
}
