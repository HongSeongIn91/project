package review.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import review.dao.ReviewContentDao;
import review.dao.ReviewDao;
import review.model.Review;
import member.dao.JdbcUtil;
import Connection.DBConnection;


public class DeleteReviewService {

	private ReviewDao reviewDao = new ReviewDao();
	private ReviewContentDao contentDao = new ReviewContentDao();
	
	
	public void delete(DeleteRequest delReq) throws ClassNotFoundException, NamingException, ReviewNotFoundException {
		Connection conn = null;
		try{
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			Review review = reviewDao.selectByRvNum(conn, delReq.getRv_num());
			if(review == null) {
				throw new ReviewNotFoundException();
			}
			if(!canDelete(delReq.getUserId(), review)) {
				throw new PermissionDeniedException();
			}
			contentDao.delete(conn, delReq.getRv_num());
			reviewDao.delete(conn, delReq.getRv_num());
			
			conn.commit();
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

	private boolean canDelete(String userId, Review review) {
		return review.getRv_m_id().equals(userId);
	}
}
