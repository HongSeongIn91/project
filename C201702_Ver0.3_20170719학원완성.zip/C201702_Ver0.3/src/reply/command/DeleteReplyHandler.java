package reply.command;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import reply.service.DeleteReplyRequest;
import reply.service.DeleteReplyService;
import reply.service.ListReplyService;
import reply.service.ReplyNotFoundException;
import reply.service.ReplyPage;
import review.service.ReadReviewService;
import review.service.ReviewContentNotFoundException;
import review.service.ReviewData;
import review.service.ReviewNotFoundException;
import auth.service.User;
import mvc.command.CommandHandler;

public class DeleteReplyHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/deleteReplyForm.jsp";
	private ReadReviewService readReviewSvc = new ReadReviewService();
	private DeleteReplyService deleteReplySvc = new DeleteReplyService();
	private ListReplyService listReplySvc = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, ReviewNotFoundException, ReviewContentNotFoundException {
		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String noVal = req.getParameter("rp_num");
		String noVal1 = req.getParameter("rp_rv_num");
		String noVal2 = req.getParameter("replyPageNo");
		
		int rp_num = Integer.parseInt(noVal);
		int rp_rv_num = Integer.parseInt(noVal1);
		int replyPageNo = 1;
		if(noVal2 != null) {
			replyPageNo = Integer.parseInt(noVal2); 
		}
		
		DeleteReplyRequest delReq = new DeleteReplyRequest(authUser.getId(), rp_num, rp_rv_num, replyPageNo);
		req.setAttribute("delReq", delReq);
		
		deleteReplySvc.delete(delReq);
		
		ReviewData reviewData = readReviewSvc.getReview(rp_rv_num, false);
		req.setAttribute("reviewDate", reviewData);
		
		ReplyPage replyPage = listReplySvc.getReplyPage(replyPageNo, rp_rv_num);
		req.setAttribute("replyPage", replyPage);
		
		return "/WEB-INF/view/readReview.jsp";
		
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) {
		
		String noVal = req.getParameter("rp_num");
		String noVal1 = req.getParameter("rp_rv_num");
		String noVal2 = req.getParameter("replyPageNo");
		
		int rp_num = Integer.parseInt(noVal);
		int rp_rv_num = Integer.parseInt(noVal1);
		int replyPageNo = 1;
		if(noVal2 != null) {
			replyPageNo = Integer.parseInt(noVal2); 
		}
		
		req.setAttribute("rp_num", rp_num);
		req.setAttribute("rp_rv_num", rp_rv_num);
		req.setAttribute("replyPageNo", replyPageNo);
		
		return FORM_VIEW;
	}
}
