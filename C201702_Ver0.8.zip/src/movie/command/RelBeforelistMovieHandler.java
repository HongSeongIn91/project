package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import movie.service.ListMovieService;
import movie.service.MoviePage;
import mvc.command.CommandHandler;

public class RelBeforelistMovieHandler implements CommandHandler {
	
	private ListMovieService mlistServive = new ListMovieService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}

		MoviePage moviePage = mlistServive.getBeforeMoviePage(pageNo);
		
		req.setAttribute("moviePage", moviePage);
		return "/WEB-INF/view/relBeforelistMovie.jsp";
	}

}
