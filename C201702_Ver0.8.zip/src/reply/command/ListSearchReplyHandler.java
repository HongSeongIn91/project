package reply.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.command.CommandHandler;
import reply.service.ListReplyService;
import reply.service.ReplyPage;
import review.service.ReadReviewService;
import review.service.ReadSearchReviewService;
import review.service.ReviewData;
import review.service.SearchReviewData;

public class ListSearchReplyHandler implements CommandHandler {
	
	private ReadSearchReviewService readReviewService = new ReadSearchReviewService();
	private ListReplyService listService = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		int rv_num = Integer.parseInt(req.getParameter("rv_num"));

		String reviewSort = req.getParameter("reviewSort");
		String keyField = req.getParameter("keyField");
		String keyWord = req.getParameter("keyWord");
		String pageNoVal = req.getParameter("replypageNo");
		int replypageNo = 1;
		if(pageNoVal != null) {
			replypageNo = Integer.parseInt(pageNoVal);
		}
		// 무비로그 
		SearchReviewData searchReviewData = readReviewService.getReview(rv_num, false);	
		req.setAttribute("searchReviewData",searchReviewData);
		
		
		// 댓글 페이지 
		ReplyPage replyPage = listService.getReplyPage(replypageNo, rv_num);
		req.setAttribute("replyPage", replyPage);		
		req.setAttribute("rv_num", rv_num);
		req.setAttribute("reviewSort", reviewSort);
		req.setAttribute("keyField", keyField);
		req.setAttribute("keyWord", keyWord);
		/*System.out.println("리스트 리플 핸들러의 getCurrentPage : " + replyPage.getCurrentPage());
		System.out.println("리스트 리플 핸들러의 getStartPage : " + replyPage.getStartPage());
		System.out.println("리스트 리플 핸들러의 getEndPage : " + replyPage.getEndPage());
	*/	
		return "/WEB-INF/view/readSearchReview.jsp";
	}

}
