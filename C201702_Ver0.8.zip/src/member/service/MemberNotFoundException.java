package member.service;

public class MemberNotFoundException extends RuntimeException {

}
