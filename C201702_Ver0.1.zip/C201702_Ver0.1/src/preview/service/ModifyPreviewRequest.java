package preview.service;

import java.util.Map;

public class ModifyPreviewRequest {

	private String userId;
	private int pre_num;
	private String pre_content;
	private int mv_num;
	private int prePageNo;
	
	public ModifyPreviewRequest(String userId, int pre_num, String pre_content,
			int mv_num, int prePageNo) {
		
		this.userId = userId;
		this.pre_num = pre_num;
		this.pre_content = pre_content;
		this.mv_num = mv_num;
		this.prePageNo = prePageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getPre_num() {
		return pre_num;
	}

	public String getPre_content() {
		return pre_content;
	}

	public int getMv_num() {
		return mv_num;
	}

	public int getPrePageNo() {
		return prePageNo;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(pre_content == null || pre_content.trim().isEmpty()) {
			errors.put("pre_content", Boolean.TRUE);
		}
	}
	
	
}
