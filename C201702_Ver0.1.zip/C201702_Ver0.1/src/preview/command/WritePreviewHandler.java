package preview.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import preview.service.ListPreviewService;
import preview.service.PreviewPage;
import preview.service.WritePreviewRequest;
import preview.service.WritePreviewService;
import auth.service.User;
import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;

public class WritePreviewHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/readMovie.jsp";
	
	private WritePreviewService writePreSvc = new WritePreviewService();
	private ReadMovieService readMovieSvc = new ReadMovieService();
	private ListPreviewService listPreSvc = new ListPreviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);

		User user = (User) req.getSession(false).getAttribute("authUser");

		String noVal1 = req.getParameter("mv_num"); // 영화번호
		int mv_num = Integer.parseInt(noVal1);
//		int prePageNo = 1;
		int prePageNo = Integer.parseInt(req.getParameter("preEndPage"));
		
		WritePreviewRequest writePreReq = createWritePreviewRequest(user, req);
		writePreReq.validate(errors);
		if(!errors.isEmpty()) {
			return FORM_VIEW;
		}
		
		int newPre_num = writePreSvc.write(writePreReq);
		MovieData movieData = readMovieSvc.getMovie(mv_num, false);
		PreviewPage prePage = listPreSvc.getPreviewPage(prePageNo, mv_num);
		
		req.setAttribute("newPre_num", newPre_num);
		req.setAttribute("movieData", movieData);
		req.setAttribute("prePage", prePage);
				
		return FORM_VIEW;
	}

	private WritePreviewRequest createWritePreviewRequest(User user,
			HttpServletRequest req) {
		
		return new WritePreviewRequest(
				user.getId(),
				req.getParameter("content"),
				Integer.parseInt(req.getParameter("mv_num"))
				);
		
	}

}
