package preview.command;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import preview.service.DeletePreviewRequest;
import preview.service.DeletePreviewService;
import preview.service.ListPreviewService;
import preview.service.PreviewNotFoundException;
import preview.service.PreviewPage;
import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;

public class DeletePreviewHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/deletePreviewForm.jsp";
	
	private DeletePreviewService delPreSvc = new DeletePreviewService();
	private ReadMovieService readMovieSvc = new ReadMovieService();
	private ListPreviewService listPreSvc = new ListPreviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, PreviewNotFoundException, SQLException {
		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String noVal = req.getParameter("pre_num");	
		String noVal1 = req.getParameter("mv_num");	
		String noVal2 = req.getParameter("prePageNo");
		
		int pre_num = Integer.parseInt(noVal);
		int mv_num = Integer.parseInt(noVal1);		
		int prePageNo = 1;
		if(noVal2 != null) {
			prePageNo = Integer.parseInt(noVal2);
		}
		
		DeletePreviewRequest delPreReq = new DeletePreviewRequest(
				authUser.getId(),
				pre_num,
				mv_num,
				prePageNo
				);
		req.setAttribute("delPreReq", delPreReq);
		
		delPreSvc.delete(delPreReq);
		
		MovieData movieData = readMovieSvc.getMovie(mv_num, false);
		PreviewPage prePage = listPreSvc.getPreviewPage(prePageNo, mv_num);
		
		req.setAttribute("movieData", movieData);
		req.setAttribute("prePage", prePage);
		
		return "/WEB-INF/view/readMovie.jsp";
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		String noVal = req.getParameter("pre_num");	
		String noVal1 = req.getParameter("mv_num");	
		String noVal2 = req.getParameter("prePageNo");
		
		int pre_num = Integer.parseInt(noVal);
		int mv_num = Integer.parseInt(noVal1);		
		int prePageNo = 1;
		if(noVal2 != null) {
			prePageNo = Integer.parseInt(noVal2);
		}
		
		req.setAttribute("pre_num", pre_num);
		req.setAttribute("mv_num", mv_num);
		req.setAttribute("prePageNo", prePageNo);
		
		return FORM_VIEW;
	}
}
