package preview.command;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import auth.service.User;
import movie.service.MovieData;
import movie.service.MovieNotFoundException;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;
import preview.service.ListPreviewService;
import preview.service.ModifyPreviewRequest;
import preview.service.ModifyPreviewService;
import preview.service.PreviewPage;
import review.service.PermissionDeniedException;

public class ModifyPreviewHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/modifyPreviewForm.jsp";

	private ReadMovieService readMovieSvc = new ReadMovieService();
	private ModifyPreviewService modPreSvc = new ModifyPreviewService();
	private ListPreviewService listPreSvc = new ListPreviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		if (req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, IOException, SQLException {
		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String noVal = req.getParameter("pre_num");	
		String noVal1 = req.getParameter("mv_num");	
		String noVal2 = req.getParameter("prePageNo");
		
		int pre_num = Integer.parseInt(noVal);
		int mv_num = Integer.parseInt(noVal1);		
		int prePageNo = 1;
		if(noVal2 != null) {
			prePageNo = Integer.parseInt(noVal2);
		}
		
		ModifyPreviewRequest modPreReq = new ModifyPreviewRequest(
				authUser.getId(),
				pre_num, 
				req.getParameter("content"), 
				mv_num, 
				prePageNo
				);
		req.setAttribute("modPreReq", modPreReq);
		
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		modPreReq.validate(errors);
		if (!errors.isEmpty()) {
			return FORM_VIEW;
		}
		
		try {
			modPreSvc.modify(modPreReq);
			
			MovieData movieData = readMovieSvc.getMovie(mv_num, false);
			PreviewPage prePage = listPreSvc.getPreviewPage(prePageNo, mv_num);
			
			req.setAttribute("movieData", movieData);
			req.setAttribute("prePage", prePage);
			
			return "/WEB-INF/view/readMovie.jsp";					
		} catch (MovieNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		} catch (PermissionDeniedException e) {
			res.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
		
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ClassNotFoundException, NamingException {
		
		try {
			
			String noVal = req.getParameter("pre_num");	
			String noVal1 = req.getParameter("mv_num");	
			String noVal2 = req.getParameter("prePageNo");
			
			int pre_num = Integer.parseInt(noVal);
			int mv_num = Integer.parseInt(noVal1);		
			int prePageNo = 1;
			if(noVal2 != null) {
				prePageNo = Integer.parseInt(noVal2);
			}

			req.setAttribute("pre_num", pre_num);		// 댓글 번호
			req.setAttribute("mv_num", mv_num);		// 감상평 번호
			req.setAttribute("prePageNo", prePageNo);		// 댓글 페이지 번호
			
			
			return FORM_VIEW;

		} catch (PermissionDeniedException e) {
			res.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
	}


	
	
}
