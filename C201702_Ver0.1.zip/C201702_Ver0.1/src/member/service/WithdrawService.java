package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import member.dao.MemberDao;

public class WithdrawService {

	private MemberDao memberDao = new MemberDao();
	
	public void withdraw(String m_id) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
		System.out.println("WithdrawService_m_id= "+m_id);
			int check = memberDao.delete(conn, m_id);
		System.out.println("WithdrawService_check= "+check);
			
		System.out.println("WithdrawService의 try{}가 끝나는 곳. commit()이전.");
			conn.commit();
		System.out.println("WithdrawService의 try{}가 끝나는 곳. commit()이후.");
			
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}

}
