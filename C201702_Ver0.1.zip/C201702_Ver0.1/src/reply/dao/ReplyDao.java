package reply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import reply.model.Reply;
import member.dao.JdbcUtil;

public class ReplyDao {
	
	public int selectCountByMyId(Connection conn, String rp_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			pstmt = conn.prepareStatement("select count(*) from review_reply where rp_m_id=?");
			pstmt.setString(1, rp_m_id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<Reply> selectByMyId(Connection conn, int startRow, int size, String rp_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT * FROM REVIEW_REPLY WHERE RP_M_ID= ? ORDER BY RP_NUM DESC"
					+ ") A WHERE ROWNUM <= ?"
					+ ") WHERE RNUM >= ?"
					);
			
			pstmt.setString(1, rp_m_id);
			pstmt.setInt(2, startRow+size);
			pstmt.setInt(3, startRow);
			
			
			rs = pstmt.executeQuery();
			List<Reply> result = new ArrayList<Reply>();
			while(rs.next()) {
				result.add(convertReply(rs));
			}
			
			return result;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private Reply convertReply(ResultSet rs) throws SQLException {
		return new Reply(rs.getInt("rp_num"),
						  rs.getInt("rp_rv_num"),
						  rs.getString("rp_m_id"),
						  toDate(rs.getTimestamp("rp_regdate")),
						  rs.getString("rp_content")
						  );
	}
	
	private static Date toDate(Timestamp timestamp) {
			
			return new Date(timestamp.getTime());
		}
	

	
public int selectCount(Connection conn, int rv_num) throws SQLException {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0 ;
		
		try {
			pstmt = conn.prepareStatement("select count(*) from review_reply where rp_rv_num=?");
			pstmt.setInt(1, rv_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
				return result;	
		
		} else {
			return result;
		}
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
	
	

	public List<Reply> select(Connection conn, int startRow, int size, int rp_rv_num) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement("select * from ("
					+ "select rownum as rnum, A.* from ("
					+ "select rr.* from review_reply rr, review rv where rr.rp_rv_num=rv.rv_num and rr.rp_rv_num = ? order by rp_num"
					+ ") A where rownum <= ?"
					+ ") where rnum >= ? "
					);
			pstmt.setInt(1, rp_rv_num);
			pstmt.setInt(2, startRow+size-1);
			pstmt.setInt(3, startRow);
			
			rs = pstmt.executeQuery();
			
			List<Reply> reply = new ArrayList<Reply>();
			while(rs.next()) {
				reply.add(convertReply(rs));
			}
			return reply;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
	
	
	/*public List<Reply> select(Connection conn, int rv_num) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement("select * from review_reply rr, review rv where rr.rp_rv_num=rv.rv_num and rr.rp_rv_num =? order by rp_num");
			pstmt.setInt(1, rv_num);
			rs = pstmt.executeQuery();
			
			List<Reply> reply = new ArrayList<Reply>();
			while(rs.next()) {
				reply.add(convertReply(rs));
			}
			return reply;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
		*/


	public Reply insert(Connection conn, Reply reply) throws SQLException {
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement("insert into review_reply (rp_num, rp_rv_num, rp_m_id, rp_regdate, rp_content)"
					+ "values (review_reply_sequence.nextval,?,?,?,?)");
			pstmt.setInt(1, reply.getRp_rv_num());
			pstmt.setString(2, reply.getRp_m_id());
			pstmt.setTimestamp(3, toTimestamp(reply.getRp_regdate()));
			pstmt.setString(4, reply.getRp_content());
			
			int insertedCount = pstmt.executeUpdate();
			
			if(insertedCount > 0) {
				stmt = conn.createStatement();
				rs = stmt.executeQuery("select review_reply_sequence.currval from review_reply");
				
				if(rs.next()) {
					Integer newNum = rs.getInt(1);
					return new Reply(newNum, reply.getRp_rv_num(), reply.getRp_m_id(), reply.getRp_regdate(), reply.getRp_content());
				}
			}
			return null;
		}finally{
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
			JdbcUtil.close(pstmt);
		}
	}

	private Timestamp toTimestamp(Date date) {
		return new Timestamp(date.getTime());
	}

	public int update(Connection conn, int rp_num, String rp_content) throws SQLException {
		try(PreparedStatement pstmt = conn.prepareStatement(
				"update review_reply set rp_content = ? where rp_num = ?")) {
			pstmt.setString(1, rp_content);
			pstmt.setInt(2, rp_num);
			return pstmt.executeUpdate();
		}
		
	}

	public int delete(Connection conn, int rp_num) throws SQLException {
		try(PreparedStatement pstmt = conn.prepareStatement(
				"delete from review_reply where rp_num = ?")) {
			pstmt.setInt(1, rp_num);
			return pstmt.executeUpdate();
		}
	}
}
