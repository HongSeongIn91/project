package reply.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import reply.service.ListReplyService;
import reply.service.ReplyPage;
import reply.service.WriteReplyRequest;
import reply.service.WriteReplyService;
import review.service.ReadReviewService;
import review.service.ReviewData;
import auth.service.User;
import mvc.command.CommandHandler;

public class WriteReplyHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/readReview.jsp";
	private WriteReplyService writeReplySvc = new WriteReplyService();
	private ReadReviewService readReviewSvc = new ReadReviewService();
	private ListReplyService listReplySvc = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		User user = (User)req.getSession(false).getAttribute("authUser");
		
		String noVal = req.getParameter("rp_rv_num");
		int rp_rv_num = Integer.parseInt(noVal);
		int replyPageNo = Integer.parseInt(req.getParameter("replyEndPage"));
		System.out.println(" replyPageNo-> " + replyPageNo);
		
		
		WriteReplyRequest writeReplyReq = createWriteReplyRequest(user, req);
		writeReplyReq.validate(errors);
		
		if(!errors.isEmpty()) {
			return FORM_VIEW;
		}
		
		int newRp_num = writeReplySvc.write(writeReplyReq);
		ReviewData reviewData = readReviewSvc.getReview(rp_rv_num, false);
		ReplyPage replyPage = listReplySvc.getReplyPage(replyPageNo, rp_rv_num);
		
		/*req.setAttribute("newRp_num", newRp_num);*/
		req.setAttribute("reviewData", reviewData);
		req.setAttribute("replyPage", replyPage);
		
		return FORM_VIEW;
	}

	private WriteReplyRequest createWriteReplyRequest(User user,
			HttpServletRequest req) {
	
		return new WriteReplyRequest(
				user.getId(),
				req.getParameter("content"),
				Integer.parseInt(req.getParameter("rp_rv_num"))
				);
		
	}

}
