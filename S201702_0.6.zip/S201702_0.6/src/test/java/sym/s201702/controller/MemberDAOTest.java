package sym.s201702.controller;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import sym.s201702.DAO.MemberDAO;
import sym.s201702.domain.MemberVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations ={"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})

public class MemberDAOTest {

	@Inject
	private MemberDAO dao;
	
	@Test
	public void testTime() {
		
		System.out.println(dao.getTime());
	}
	
	@Test
	public void testInsertMember() {
		
		MemberVO vo = new MemberVO();
		vo.setM_id("aaabbb");
		vo.setM_pw("123123");
		vo.setM_birth("19910208");
		vo.setM_gender("M");
		vo.setM_email("hsi2799@naver.com");
		vo.setM_phone("010-4111-2222");
		
		/*dao.insert(vo);*/
	}
}
