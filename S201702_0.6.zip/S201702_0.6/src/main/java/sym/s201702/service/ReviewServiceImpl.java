package sym.s201702.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.ReviewContentDAO;
import sym.s201702.DAO.ReviewDAO;
import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReviewContentVO;
import sym.s201702.domain.ReviewData;
import sym.s201702.domain.ReviewVO;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Inject
	private ReviewDAO reviewDao;
	
	@Inject
	private ReviewContentDAO contentDao;

	@Override
	public void regist(WriteReviewDTO dto) throws Exception {

		reviewDao.create(dto);
		contentDao.create(dto);
		
	}

	@Override
	public List<ReviewVO> listCriteria(Criteria cri) throws Exception {
		
		return reviewDao.listCriteria(cri);
	}

	@Override
	public int listCountCriteria(Criteria cri) throws Exception {
		
		return reviewDao.countPaging(cri);
	}

	@Override
	public ReviewData read(Integer rv_num) throws Exception {
		
		ReviewVO review = reviewDao.read(rv_num);
		ReviewContentVO content = contentDao.read(rv_num);
		
		return new ReviewData(review, content);
	}

	@Override
	public void remove(Integer rv_num) throws Exception {
		
		reviewDao.delete(rv_num);
		contentDao.delete(rv_num);
		
	}

	@Override
	public void modify(ModifyReviewDTO dto) throws Exception {
		
		reviewDao.update(dto);
		contentDao.update(dto);
		
	}

	@Override
	public List<ReviewVO> listSearchCriteria(SearchCriteria cri) throws Exception {
		
		return reviewDao.listSearch(cri);
	}

	@Override
	public int listSearchCount(SearchCriteria cri) throws Exception {
		
		return reviewDao.listSearchCount(cri);
	}

}
