package sym.s201702.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import sym.s201702.DAO.ReplyDAO;
import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReplyVO;

@Service
public class ReplyServiceImpl implements ReplyService {

	@Inject
	private ReplyDAO dao;
	
	@Override
	public void regist(ReplyVO vo) throws Exception {
		
		dao.create(vo);

	}

	@Override
	public List<ReplyVO> list(Integer rp_rv_num, Criteria cri) throws Exception {
		
		return dao.list(rp_rv_num, cri);
	}
	
	@Override
	public int count(Integer rp_rv_num) throws Exception {
		
		return dao.count(rp_rv_num);
	}

	@Override
	public void modify(ReplyVO vo) throws Exception {
		
		dao.update(vo);

	}

	@Override
	public void remove(Integer rp_num) throws Exception {
		
		dao.delete(rp_num);

	}

}
