package sym.s201702.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import sym.s201702.domain.MemberVO;
import sym.s201702.dto.ChangeMemberDTO;
import sym.s201702.dto.MemberDTO;
import sym.s201702.exception.DuplicateIdException;
import sym.s201702.exception.InvalidPasswordException;
import sym.s201702.exception.NotMatchConfirmPasswordException;
import sym.s201702.service.MemberService;

@Controller
@RequestMapping(value = "/member/*")
public class MemberController {

	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Inject
	private MemberService service;
	
	@RequestMapping(value = "/terms")
	public void joinTerms() {
		
		logger.info("****************** join Terms ******************");
	}
	
	@RequestMapping(value = "/joinForm", method = RequestMethod.GET)
	public void JoinGET(MemberDTO dto, Model model) {
		
		logger.info("****************** join GET ******************");
	}
	
	@RequestMapping(value = "/joinForm", method = RequestMethod.POST)
	public String JoinPOST(MemberDTO dto) throws Exception {
		
		logger.info("****************** join POST ******************");
		logger.info(dto.toString());
		
		try {
			service.join(dto);
			return "/member/joinSuccess";
		} catch (DuplicateIdException e) {
			return "/member/joinForm";
		}
	}
	
	@RequestMapping(value = "/checkPwd", method = RequestMethod.GET)
	public void checkPwdGET() {
		
		logger.info("****************** checkPwd GET ******************");
	}
	
	@RequestMapping(value = "/checkPwd", method = RequestMethod.POST)
	public String checkPwdPOST(MemberDTO dto) throws Exception {
		
		logger.info("****************** checkPwd POST ******************");
		logger.info(dto.toString());
		
		try {
			service.checkPwd(dto);
			return "/member/changeMemberInfo";
		} catch (InvalidPasswordException e) {
			return "/member/checkPwd";
		}
	}
	
	@RequestMapping(value = "/change", method = RequestMethod.POST)
	public String changeMemberInfoPOST(ChangeMemberDTO dto) throws Exception {
		
		logger.info("****************** checkMemberInfo POST ******************");
		logger.info(dto.toString());
		
		try {
			service.changeMemberInfo(dto);
			return "myPage";
		} catch (NotMatchConfirmPasswordException e) {
			return "/member/changeMemberInfo";
		}
	}
	
	@RequestMapping(value = "/withdraw", method = RequestMethod.GET)
	public void withdrawMemberGET() {
		
		logger.info("****************** withdrawMember GET ******************");
	}
	
	@RequestMapping(value = "/withdrawPost", method = RequestMethod.POST)
	public String withdrawMemberPOST(MemberDTO dto, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		logger.info("****************** withdrawMember POST ******************");
		logger.info(dto.toString());
		
		try {
			service.checkPwd(dto);
			service.withdraw(dto);
			
			HttpSession session = request.getSession(false);
			if(session.getAttribute("authUser") != null) {
				session.invalidate();
			}
			response.sendRedirect("/");
			return null;
		} catch (InvalidPasswordException e) {
			return "/member/withdraw";
		}
		
	}
}
