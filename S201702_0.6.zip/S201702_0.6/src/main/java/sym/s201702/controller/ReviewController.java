package sym.s201702.controller;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.PageMaker;
import sym.s201702.domain.ReviewData;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;
import sym.s201702.service.MovieService;
import sym.s201702.service.ReviewService;

@Controller
@RequestMapping("/review/*")
public class ReviewController {

	private static final Logger logger = LoggerFactory.getLogger(ReviewController.class);
	
	@Inject
	private ReviewService reviewService;
	
	@Inject
	private MovieService movieService;
	
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public void writeGET(Model model) throws Exception {
		
		logger.info("********************* write review GET ***********************");
		
		model.addAttribute("movie", movieService.getMovieTitle());	
	}
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writePOST(WriteReviewDTO dto, RedirectAttributes rttr) throws Exception {
		
		logger.info("********************* write review POST ***********************");
		logger.info(dto.toString());
		
		reviewService.regist(dto);
		
		rttr.addFlashAttribute("msg", "Create SUCCESS");
		return "redirect:/review/list";
		
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public void list(@ModelAttribute("cri") SearchCriteria cri, Model model) throws Exception {
		
		logger.info("********************* list review GET ***********************");
		logger.info(cri.toString());
		
		model.addAttribute("review", reviewService.listSearchCriteria(cri));
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(reviewService.listCountCriteria(cri));
		
		model.addAttribute("pageMaker", pageMaker);
	}
	
	@RequestMapping(value = "/read", method = RequestMethod.GET)
	public void read(@RequestParam("rv_num") int rv_num, @ModelAttribute("cri") Criteria cri, Model model) throws Exception {
		
		logger.info("********************* read review GET ***********************");
		
		model.addAttribute("reviewData", reviewService.read(rv_num));
		
	}
	
	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public String remove(@RequestParam("rv_num") int rv_num, Criteria cri, RedirectAttributes rttr) throws Exception {
		
		logger.info("********************* delete review POST ***********************");
		
		reviewService.remove(rv_num);
		
		rttr.addAttribute("page", cri.getPage());
		rttr.addAttribute("perPageNum", cri.getPerPageNum());
		rttr.addFlashAttribute("msg", "Delete SUCCESS");
		return "redirect:/review/list";
	}

	@RequestMapping(value = "/modify", method = RequestMethod.GET)
	public void modifyGET(@RequestParam("rv_num") int rv_num, @ModelAttribute("cri") Criteria cri, Model model) throws Exception {
		
		logger.info("********************* modify review GET ***********************");
		
		ReviewData reviewData = reviewService.read(rv_num);
	
		ModifyReviewDTO dto = new ModifyReviewDTO();
		dto.setRv_m_id(reviewData.getReview().getRv_m_id());
		dto.setRv_num(rv_num);
		dto.setRv_title(reviewData.getReview().getRv_title());
		dto.setRvc_content(reviewData.getContent());
		
		model.addAttribute("dto", dto);
	}
	
	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	public String modifyPOST(ModifyReviewDTO dto, Criteria cri, RedirectAttributes rttr) throws Exception {
		
		logger.info("********************* modify review POST ***********************");
		logger.info(dto.toString());
		
		reviewService.modify(dto);
		
		rttr.addAttribute("page", cri.getPage());
		rttr.addAttribute("perPageNum", cri.getPerPageNum());
		rttr.addFlashAttribute("msg", "Update SUCCESS");
		return "redirect:/review/list";
	}
}
