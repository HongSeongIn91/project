package sym.s201702.exception;

public class NotMatchConfirmPasswordException extends Exception {

}
