package sym.s201702.dto;

public class WriteReviewDTO {

	private String rv_m_id;
	private int mv_num;
	private int rvc_rv_num;
	private String rv_title;
	private String rvc_content;
	
	public String getRv_m_id() {
		return rv_m_id;
	}
	public void setRv_m_id(String rv_m_id) {
		this.rv_m_id = rv_m_id;
	}
	public int getMv_num() {
		return mv_num;
	}
	public void setMv_num(int mv_num) {
		this.mv_num = mv_num;
	}
	public int getRvc_rv_num() {
		return rvc_rv_num;
	}
	public void setRvc_rv_num(int rvc_rv_num) {
		this.rvc_rv_num = rvc_rv_num;
	}
	public String getRv_title() {
		return rv_title;
	}
	public void setRv_title(String rv_title) {
		this.rv_title = rv_title;
	}
	public String getRvc_content() {
		return rvc_content;
	}
	public void setRvc_content(String rvc_content) {
		this.rvc_content = rvc_content;
	}
	
}
