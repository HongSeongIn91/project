package sym.s201702.dto;

public class ModifyReviewDTO {

	private String rv_m_id;
	private int rv_num;
	private String rv_title;
	private String rvc_content;
	
	public String getRv_m_id() {
		return rv_m_id;
	}
	public void setRv_m_id(String rv_m_id) {
		this.rv_m_id = rv_m_id;
	}
	public int getRv_num() {
		return rv_num;
	}
	public void setRv_num(int rv_num) {
		this.rv_num = rv_num;
	}
	public String getRv_title() {
		return rv_title;
	}
	public void setRv_title(String rv_title) {
		this.rv_title = rv_title;
	}
	public String getRvc_content() {
		return rvc_content;
	}
	public void setRvc_content(String rvc_content) {
		this.rvc_content = rvc_content;
	}
	
}
