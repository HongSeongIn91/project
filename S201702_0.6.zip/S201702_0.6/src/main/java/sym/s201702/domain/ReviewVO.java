package sym.s201702.domain;

import java.util.Date;

public class ReviewVO {

	private Integer rv_num;
	private Integer rv_mv_num;
	private String rv_m_id;
	private Date rv_regdate;
	private String rv_title;
	private int rv_readcnt;
	private MovieVO movie;
	
	public Integer getRv_num() {
		return rv_num;
	}
	public void setRv_num(Integer rv_num) {
		this.rv_num = rv_num;
	}
	public Integer getRv_mv_num() {
		return rv_mv_num;
	}
	public void setRv_mv_num(Integer rv_mv_num) {
		this.rv_mv_num = rv_mv_num;
	}
	public String getRv_m_id() {
		return rv_m_id;
	}
	public void setRv_m_id(String rv_m_id) {
		this.rv_m_id = rv_m_id;
	}
	public Date getRv_regdate() {
		return rv_regdate;
	}
	public void setRv_regdate(Date rv_regdate) {
		this.rv_regdate = rv_regdate;
	}
	public String getRv_title() {
		return rv_title;
	}
	public void setRv_title(String rv_title) {
		this.rv_title = rv_title;
	}
	public int getRv_readcnt() {
		return rv_readcnt;
	}
	public void setRv_readcnt(int rv_readcnt) {
		this.rv_readcnt = rv_readcnt;
	}
	public MovieVO getMovie() {
		return movie;
	}
	public void setMovie(MovieVO movie) {
		this.movie = movie;
	}
	
}
