package sym.s201702.domain;

public class ReviewContentVO {

	private Integer rvc_rv_num;
	private String rvc_content;
	
	public Integer getRvc_rv_num() {
		return rvc_rv_num;
	}
	public void setRvc_rv_num(Integer rvc_rv_num) {
		this.rvc_rv_num = rvc_rv_num;
	}
	public String getRvc_content() {
		return rvc_content;
	}
	public void setRvc_content(String rvc_content) {
		this.rvc_content = rvc_content;
	}
	
}
