package sym.s201702.DAO;

import java.util.List;

import sym.s201702.domain.MovieVO;

public interface MovieDAO {

	public List<MovieVO> relSelect() throws Exception;
}
