package sym.s201702.DAO;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.MemberVO;
import sym.s201702.dto.MemberDTO;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sqlSession;
	
	private static final String namespace = "sym.s201702.mapper.MemberMapper";
	
	@Override
	public String getTime() {
		
		return sqlSession.selectOne(namespace+".getTime");
	}

	@Override
	public void insert(MemberDTO dto) {
		
		sqlSession.insert(namespace+".insert", dto);

	}

	@Override
	public MemberVO selectById(String m_id) {
		
		return sqlSession.selectOne(namespace+".selectById", m_id);
		
	}

	@Override
	public void update(MemberVO vo) {
		
		sqlSession.update(namespace+".update", vo);
		
	}

	@Override
	public void delete(MemberDTO dto) {

		sqlSession.delete(namespace+".delete", dto);
	}

}
