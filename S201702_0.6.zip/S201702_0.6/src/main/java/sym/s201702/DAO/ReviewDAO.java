package sym.s201702.DAO;

import java.util.List;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReviewVO;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

public interface ReviewDAO {

	public WriteReviewDTO create(WriteReviewDTO dto) throws Exception;
	
	public ReviewVO read(Integer rv_num) throws Exception;
	
	public void update(ModifyReviewDTO dto) throws Exception;
	
	public  void delete(Integer rv_num) throws Exception;
	
	public List<ReviewVO> listCriteria(Criteria cri) throws Exception;
	
	public int countPaging(Criteria cri) throws Exception;
	
	public List<ReviewVO> listSearch(SearchCriteria cri) throws Exception;
	
	public int listSearchCount(SearchCriteria cri) throws Exception;
}
