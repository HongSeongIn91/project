package sym.s201702.DAO;

import java.util.List;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReplyVO;

public interface ReplyDAO {

	public List<ReplyVO> list(Integer rp_rv_num, Criteria cri) throws Exception;
	
	public int count(Integer rp_rv_num) throws Exception;
	
	public void create(ReplyVO vo) throws Exception;
	
	public void update(ReplyVO vo) throws Exception;
	
	public void delete(Integer rp_num) throws Exception;
	
}
