package sym.s201702.DAO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReplyVO;

@Repository
public class ReplyDAOImpl implements ReplyDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "sym.s201702.mapper.ReplyMapper";

	@Override
	public List<ReplyVO> list(Integer rp_rv_num, Criteria cri) throws Exception {
		
		Map<String, Object> paramMap = new HashMap<>();
		
		paramMap.put("rp_rv_num", rp_rv_num);
		paramMap.put("cri", cri);
		
		return session.selectList(namespace+".list", paramMap);
	}

	@Override
	public int count(Integer rp_rv_num) throws Exception {
		
		return session.selectOne(namespace+".count", rp_rv_num);
	}
	
	@Override
	public void create(ReplyVO vo) throws Exception {
		
		session.insert(namespace+".create", vo);

	}

	@Override
	public void update(ReplyVO vo) throws Exception {
		
		session.update(namespace+".update", vo);

	}

	@Override
	public void delete(Integer rp_num) throws Exception {
		
		session.delete(namespace+".delete", rp_num);

	}



}
