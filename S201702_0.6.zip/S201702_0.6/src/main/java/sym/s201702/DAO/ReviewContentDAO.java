package sym.s201702.DAO;

import sym.s201702.domain.ReviewContentVO;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

public interface ReviewContentDAO {

	public void create(WriteReviewDTO dto) throws Exception;
	
	public ReviewContentVO read(Integer rv_num) throws Exception;
	
	public void update(ModifyReviewDTO dto) throws Exception;
	
	public void delete(Integer rv_num) throws Exception;
	
}
