package sym.s201702.DAO;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.Criteria;
import sym.s201702.domain.ReviewVO;
import sym.s201702.domain.SearchCriteria;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "sym.s201702.mapper.ReviewMapper";
	
	@Override
	public WriteReviewDTO create(WriteReviewDTO dto) throws Exception {
		
		session.insert(namespace+".create", dto);
		
		int rvc_rv_num = session.selectOne(namespace+".presentRv_num");
		
		dto.setRvc_rv_num(rvc_rv_num);
		
		return dto;
		
	}
	
	@Override
	public List<ReviewVO> listCriteria(Criteria cri) throws Exception {
		
		return session.selectList(namespace+".listCriteria", cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		
		return session.selectOne(namespace+".countPaging", cri);
	}

	@Override
	public ReviewVO read(Integer rv_num) throws Exception {
		
		return session.selectOne(namespace+".read", rv_num);
	}

	@Override
	public void delete(Integer rv_num) throws Exception {
		
		session.delete(namespace+".delete", rv_num);
		
	}

	@Override
	public void update(ModifyReviewDTO dto) throws Exception {
		
		session.update(namespace+".update", dto);
		
	}

	@Override
	public List<ReviewVO> listSearch(SearchCriteria cri) throws Exception {
		
		return session.selectList(namespace+".listSearch", cri);
	}

	@Override
	public int listSearchCount(SearchCriteria cri) throws Exception {
		
		return session.selectOne(namespace+".listSearchCount", cri);
	}

	

	

}
