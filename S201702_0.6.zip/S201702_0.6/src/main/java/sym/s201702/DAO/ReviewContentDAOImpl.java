package sym.s201702.DAO;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import sym.s201702.domain.ReviewContentVO;
import sym.s201702.dto.ModifyReviewDTO;
import sym.s201702.dto.WriteReviewDTO;

@Repository
public class ReviewContentDAOImpl implements ReviewContentDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "sym.s201702.mapper.ReviewContentMapper";
	
	@Override
	public void create(WriteReviewDTO dto) throws Exception {

		session.insert(namespace+".create", dto);

	}

	@Override
	public ReviewContentVO read(Integer rv_num) throws Exception {
		
		return session.selectOne(namespace+".read", rv_num);
	}

	@Override
	public void delete(Integer rv_num) throws Exception {
		
		session.delete(namespace+".delete", rv_num);
	}

	@Override
	public void update(ModifyReviewDTO dto) throws Exception {
		
		session.update(namespace+".update", dto);
		
	}

}
