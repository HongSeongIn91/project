package myUpload.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import preview.model.Preview;
import preview.service.PreviewPage;
import reply.model.Reply;
import reply.service.ReplyPage;
import review.model.Review;
import review.service.ReviewPage;
import Connection.DBConnection;
import preview.dao.PreviewDao;
import reply.dao.ReplyDao;
import review.dao.ReviewDao;

public class ListService {

	private ReviewDao reviewDao = new ReviewDao();
	private PreviewDao previewDao = new PreviewDao();
	private ReplyDao replyDao = new ReplyDao();
	private int size = 10;
	
	public ReviewPage getReviewPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = reviewDao.selectCountByMyId(conn, m_id);
			List<Review> content = reviewDao.selectByMyId(conn, (pageNum-1)*size, size, m_id);
			return new ReviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public PreviewPage getPreviewPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = previewDao.selectCountByMyId(conn, m_id);
			List<Preview> content = previewDao.selectByMyId(conn, (pageNum-1)*size, size, m_id);
			return new PreviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ReplyPage getReplyPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = replyDao.selectCountByMyId(conn, m_id);
			List<Reply> content = replyDao.selectByMyId(conn, (pageNum-1)*size, size, m_id);
			return new ReplyPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
