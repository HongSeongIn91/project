package review.service;

public class ReviewContentNotFoundException extends Exception {

}
