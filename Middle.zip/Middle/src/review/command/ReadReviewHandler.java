package review.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import review.service.ReadReviewService;
import review.service.ReviewContentNotFoundException;
import review.service.ReviewData;
import review.service.ReviewNotFoundException;
import mvc.command.CommandHandler;

public class ReadReviewHandler implements CommandHandler {

	private ReadReviewService readService = new ReadReviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		String noVal = req.getParameter("rv_num");
		int rv_num = Integer.parseInt(noVal);
		System.out.println("ReadReviewHandler_rv_num= "+rv_num );
		
		try {
			ReviewData reviewData = readService.getReview(rv_num, true);
			req.setAttribute("reviewData", reviewData);
			return "/WEB-INF/view/readReview.jsp";
		} catch (ReviewNotFoundException | ReviewContentNotFoundException e) {
			req.getServletContext().log("no review", e);
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

}
