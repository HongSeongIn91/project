package review.model;

import java.util.Date;

import movie.model.Movie;

public class Review {

	private Integer rv_num;
	private Integer rv_mv_num;
	private String rv_m_id;
	private Date rv_regdate;
	private String rv_title;
	private int rv_readcnt;
	private Movie movie;
	
	public Review(Integer rv_num, Integer rv_mv_num, String rv_m_id,
			Date rv_regdate, String rv_title, int rv_readcnt, Movie movie) {
		super();
		this.rv_num = rv_num;
		this.rv_mv_num = rv_mv_num;
		this.rv_m_id = rv_m_id;
		this.rv_regdate = rv_regdate;
		this.rv_title = rv_title;
		this.rv_readcnt = rv_readcnt;
		this.movie=movie;
	}

	public Integer getRv_num() {
		return rv_num;
	}

	public Integer getRv_mv_num() {
		return rv_mv_num;
	}

	public String getRv_m_id() {
		return rv_m_id;
	}

	public Date getRv_regdate() {
		return rv_regdate;
	}

	public String getRv_title() {
		return rv_title;
	}

	public int getRv_readcnt() {
		return rv_readcnt;
	}
	
	public Movie getMovie() {
		return movie;
	}
}
