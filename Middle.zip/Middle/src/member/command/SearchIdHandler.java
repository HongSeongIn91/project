package member.command;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.model.Member;
import member.service.MemberNotFoundException;
import member.service.SearchIdService;
import mvc.command.CommandHandler;

public class SearchIdHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/searchIdForm.jsp";
	private SearchIdService SearchIdSvc = new SearchIdService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if(req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException {
		String regnum = trim(req.getParameter("regnum"));
		String email = trim(req.getParameter("email"));
		
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		if(regnum==null || regnum.isEmpty())
			errors.put("regnum", Boolean.TRUE);
		if(email==null || email.isEmpty())
			errors.put("email", Boolean.TRUE);
		
		if(!errors.isEmpty()){
			return FORM_VIEW;
		}
		
		try {
			Member member = SearchIdSvc.searchId(regnum, email);
			req.getSession().setAttribute("member", member);
			return "/WEB-INF/view/searchIdSuccess.jsp";
		} catch (MemberNotFoundException e) {
			errors.put("regnumOrEmailNotMatch", Boolean.TRUE);
			return FORM_VIEW;
		}
		
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) {
		
		return FORM_VIEW;
	}
	
	private String trim(String str) {
		
		return str == null ? null : str.trim();
	}

}
