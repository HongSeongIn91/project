package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import movie.service.MovieData;
import movie.service.MovieNotFoundException;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;

public class ReadMovieHandler implements CommandHandler {

	private ReadMovieService readService = new ReadMovieService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		String noVal = req.getParameter("mv_num");
		int mv_num = Integer.parseInt(noVal);
		
		try {
			//MovieData객체는 추후 기대평과 합치기위한 목적으로 남겨둔다
			MovieData movieData = readService.getMovie(mv_num, true);
			req.setAttribute("movieData", movieData);
			//값을 가져와서 movieData객체에담아 readArticle.jsp로감
			return "/WEB-INF/view/readMovie.jsp";
		} catch (MovieNotFoundException e) {
			req.getServletContext().log("no movie", e);
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

	
}
