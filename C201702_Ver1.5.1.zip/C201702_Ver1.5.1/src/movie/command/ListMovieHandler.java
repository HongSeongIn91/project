package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import movie.service.ListMovieService;
import movie.service.MoviePage;
import mvc.command.CommandHandler;

public class ListMovieHandler implements CommandHandler {

	private ListMovieService mlistServive = new ListMovieService();
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {

		String movietop = "[전체상영작]";
		
		String Sort= req.getParameter("movieSort");
		String movieSort = "mv_readcnt";
		if(Sort!=null){
			movieSort=Sort;
		}
		
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}

		MoviePage moviePage = mlistServive.getMoviePage(pageNo, movieSort);
		
		req.setAttribute("movietop", movietop);
		req.setAttribute("moviePage", moviePage);
		req.setAttribute("movieSort", movieSort);
		return "/WEB-INF/view/listMovie.jsp";
	}

}
