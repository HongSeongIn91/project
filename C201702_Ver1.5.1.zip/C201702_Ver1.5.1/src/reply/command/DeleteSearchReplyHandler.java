package reply.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import reply.service.DeleteReplyRequest;
import reply.service.DeleteReplyService;
import reply.service.ListReplyService;
import reply.service.ReplyPage;
import review.service.ReadReviewService;
import review.service.ReadSearchReviewService;
import review.service.ReviewData;
import review.service.SearchReviewData;
import auth.service.User;
import mvc.command.CommandHandler;

public class DeleteSearchReplyHandler implements CommandHandler {

	private ReadSearchReviewService readReviewSvc = new ReadSearchReviewService();
	private DeleteReplyService deleteReplySvc = new DeleteReplyService();
	private ListReplyService listReplySvc = new ListReplyService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {


		User authUser = (User) req.getSession().getAttribute("authUser");

		String reviewSort = req.getParameter("reviewSort");// 소팅
		String pageNo = req.getParameter("pageNo");// 페이지번호
		String noVal = req.getParameter("rp_num");// 댓글번호
		String noVal1 = req.getParameter("rp_rv_num");// 게시물번호
		String noVal2 = req.getParameter("replyPageNo");// 페이지번호
		String keyField = req.getParameter("keyField");
		String keyWord = req.getParameter("keyWord");

		int rp_num = Integer.parseInt(noVal);
		int rp_rv_num = Integer.parseInt(noVal1);
		int replyPageNo = 1;
		if (noVal2 != null) {
			replyPageNo = Integer.parseInt(noVal2);
		}

		if(reviewSort==null){
			reviewSort="rv_num";
		}
		
		DeleteReplyRequest delReq = new DeleteReplyRequest(authUser.getId(),
				rp_num, rp_rv_num, replyPageNo);

		SearchReviewData searchReviewData = readReviewSvc.getReview(rp_rv_num, false);
		
		
		deleteReplySvc.delete(delReq);

		ReplyPage replyPage = listReplySvc.getReplyPage(replyPageNo, rp_rv_num);

		req.setAttribute("delReq", delReq);
		req.setAttribute("pageNo", pageNo);
		req.setAttribute("rp_rv_num", rp_rv_num);
		req.setAttribute("searchReviewData", searchReviewData);
		req.setAttribute("replyPage", replyPage);
		req.setAttribute("reviewSort", reviewSort);
		req.setAttribute("keyWord", keyWord);
		req.setAttribute("keyField", keyField);

		return "/WEB-INF/view/readSearchReview.jsp";

	}
}
