package myUpload.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import mvc.command.CommandHandler;
/*import myUpload.service.ListService;*/
import review.service.ListReviewService;
import review.service.ReviewPage;

public class ViewMyReviewHandler implements CommandHandler {

	private ListReviewService listService = new ListReviewService();
	/*private ListService listService = new ListService();*/
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		User user = (User)req.getSession().getAttribute("authUser");
		/*System.out.println(user.getId());*/
		
		String pageNoVal = req.getParameter("pageNo");
		String reviewSort = req.getParameter("reviewSort");
		
		int pageNo = 1;
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		if(reviewSort==null){
			reviewSort="rv_num";
		}
		
		ReviewPage reviewPage = listService.getMyReviewPage(pageNo, reviewSort, user.getId());
		
		int startNum = listService.getTotalPage(pageNo, reviewPage.getTotal());
		
		req.setAttribute("reviewPage", reviewPage);
		req.setAttribute("startNum", startNum);
		req.setAttribute("reviewSort", reviewSort);
		return "/WEB-INF/view/listMyReview.jsp";
	}

}
