package myUpload.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import mvc.command.CommandHandler;
import myUpload.service.myPreviewPage;
import preview.service.ListPreviewService;


public class ViewMyPreviewHandler implements CommandHandler {

	private ListPreviewService listService = new ListPreviewService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		User user = (User)req.getSession().getAttribute("authUser");
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		
		myPreviewPage myPreviewPage = listService.getMyPreviewPage(user.getId(), pageNo);
		req.setAttribute("myPreviewPage", myPreviewPage);
		return "/WEB-INF/view/listMyPreview.jsp";
	}

}
