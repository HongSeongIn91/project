package member.service;

public class DismatchPasswordException extends RuntimeException {

}
