package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import member.dao.MemberDao;
import member.model.Member;

public class ChangeMemberInfoService {

	private MemberDao memberDao = new MemberDao();
	
	public void changeMemberInfo(String m_id, String newPwd, String confirmPassword, String newEmail,
			String newPhone) throws ClassNotFoundException, NamingException, NotMatchConfirmPasswordException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			Member member = memberDao.selectById(conn, m_id);
			/*if (member.getM_pw().equals(newPwd)) {
				throw new DismatchPasswordException();
			}*/
			if (!matchPassword(newPwd, confirmPassword)) {
				throw new NotMatchConfirmPasswordException();
			}
			
			if (member == null) {
				throw new MemberNotFoundException();
			}
			
			member.changePassword(newPwd);
			member.changeEmail(newEmail);
			member.changePhone(newPhone);
			
			MemberDao.update(conn, member);
			conn.commit();	
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}
	
	private boolean matchPassword(String newPwd, String confirmPassword) {
		return confirmPassword.equals(newPwd);
	}
}
