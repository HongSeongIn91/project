package reply.service;

import java.util.Map;

public class DeleteReplyRequest {

	private String userId;
	private int rp_num;
	private int rp_rv_num;
	private int replyPageNo;
	
	public DeleteReplyRequest(String userId, int rp_num, int rp_rv_num,
			int replyPageNo) {
		super();
		this.userId = userId;
		this.rp_num = rp_num;
		this.rp_rv_num = rp_rv_num;
		this.replyPageNo = replyPageNo;
	}
	
	public String getUserId() {
		return userId;
	}
	public int getRp_num() {
		return rp_num;
	}
	public int getRp_rv_num() {
		return rp_rv_num;
	}
	public int getReplyPageNo() {
		return replyPageNo;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(userId == null || userId.trim().isEmpty()) {
			errors.put("userId", Boolean.TRUE);
		}
	}

}
