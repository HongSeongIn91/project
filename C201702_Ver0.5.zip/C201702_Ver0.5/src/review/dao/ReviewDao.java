package review.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import review.model.Review;
import member.dao.JdbcUtil;
import movie.model.Movie;

public class ReviewDao {

	// 글 내용삽입
	public Review insert(Connection conn, Review review) throws SQLException {
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn
					.prepareStatement("insert into review "
							+ "(rv_num, rv_mv_num, rv_m_id, rv_regdate, rv_title, rv_readcnt) "
							+ "values (review_sequence.nextval, ?, ?, ?, ?, 0)");
			// 게시물번호,영화번호,글쓴이,쓴날짜,제목,조회수

			pstmt.setInt(1, review.getRv_mv_num());
			pstmt.setString(2, review.getRv_m_id());
			pstmt.setTimestamp(3, toTimestamp(review.getRv_regdate()));
			pstmt.setString(4, review.getRv_title());

			// 인설트 결과 받아옴
			int insertedCount = pstmt.executeUpdate();

			// 인설트개수가 0보다 크면
			if (insertedCount > 0) {
				stmt = conn.createStatement();
				// 그 최근 번호를 받아서select
				rs = stmt
						.executeQuery("select Review_SEQUENCE.CURRVAL from review");
				if (rs.next()) {
					// 객체에 담아
					Integer newNum = rs.getInt(1);// 최근번호 알려줌
					return new Review(newNum, review.getRv_mv_num(),
							review.getRv_m_id(), review.getRv_regdate(),
							review.getRv_title(), 0, null);

				}
			}
			return null;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
			JdbcUtil.close(pstmt);

		}
	}

	private Timestamp toTimestamp(Date date) {

		return new Timestamp(date.getTime());
	}

	public int selectCount(Connection conn) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select count(*) from review");
			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}
	}

	public List<Review> select(Connection conn, int startRow, int size,
			String reviewSort) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM ( SELECT ROWNUM AS rnum, A.* FROM (";
		if (reviewSort.equals("rv_num")) {
			sql += "select rv.*, mv.mv_title from review rv, movie_info mv where rv.rv_mv_num=mv.mv_num ORDER BY rv_num DESC";
		} else if (reviewSort.equals("rv_readcnt")) {
			sql += "select rv.*, mv.mv_title from review rv, movie_info mv where rv.rv_mv_num=mv.mv_num ORDER BY rv_readcnt DESC";
		}
		sql += ") A WHERE ROWNUM <= ?) WHERE RNUM >=?";

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, startRow + size - 1);
			pstmt.setInt(2, startRow); // 21
			rs = pstmt.executeQuery();

			List<Review> result = new ArrayList<Review>();
			while (rs.next()) {

				result.add(convertReview(rs));
			}
			return result;
			/*
			 * try {
			 * 
			 * pstmt = conn.prepareStatement( "SELECT * FROM (" +
			 * "SELECT ROWNUM AS rnum, A.* FROM (" +
			 * "SELECT rv.*, mv.mv_title FROM REVIEW rv, MOVIE_INFO mv " +
			 * "WHERE rv.rv_mv_num=mv.mv_num ORDER BY rv.rv_num DESC ) A " +
			 * "WHERE ROWNUM <= ?)" + " WHERE RNUM >=?" );
			 * 
			 * "SELECT * FROM (" + "SELECT ROWNUM AS rnum, A.* FROM (" +
			 * "SELECT * FROM review ORDER BY rv_num DESC" +
			 * ") A WHERE ROWNUM <= ?" + ") WHERE RNUM >= ?");
			 * 
			 * pstmt.setInt(1, startRow + size - 1); pstmt.setInt(2, startRow);
			 * rs = pstmt.executeQuery();
			 * 
			 * // 목록리스트를 Arraylist에 담는다 // result 객체리스트를 생성한다 List<Review>
			 * result = new ArrayList<Review>(); while (rs.next()) {
			 * result.add(convertReview(rs)); } return result;
			 */
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private static Review convertReview(ResultSet rs) throws SQLException {

		return new Review(rs.getInt("rv_num"), rs.getInt("rv_mv_num"),
				rs.getString("rv_m_id"), toDate(rs.getTimestamp("rv_regdate")),
				rs.getString("rv_title"), rs.getInt("rv_readcnt"), new Movie(
						rs.getString("mv_title")));

	}

	private static Date toDate(Timestamp timestamp) {

		return new Date(timestamp.getTime());
	}

	// 게시물 번호를 가지고 selelct 처리 해서
	// converArticle페이지에서 결과 에대한 정보를 article객체에 담아서 리턴
	public Review selectByRvNum(Connection conn, int rv_num)
			throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select rv.*, mv.mv_title "
					+ "from review rv, movie_info mv "
					+ "where rv.rv_mv_num=mv.mv_num and rv.rv_num = ?");
			pstmt.setInt(1, rv_num);
			rs = pstmt.executeQuery();
			Review review = null;
			if (rs.next()) {
				review = convertReview(rs);
			}
			return review;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public int selectCountByMyId(Connection conn, String rv_m_id)
			throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			pstmt = conn
					.prepareStatement("select count(*) from review where rv_m_id = ?");
			pstmt.setString(1, rv_m_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1);
				System.out.println("ReviewDao_rs.getInt(1):" + rs.getInt(1));
				return result;

			} else {
				return result;
			}

		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<Review> selectByMyId(Connection conn, int startRow, int size,
			String rv_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT rv.*, mv.mv_title " + "FROM movie_info mv "
					+ "INNER JOIN review rv "
					+ "ON (mv.mv_num = rv.rv_mv_num) "
					+ "WHERE rv.rv_m_id = ? ORDER BY rv.rv_num DESC) A "
					+ "WHERE ROWNUM <= ?) " + "WHERE RNUM >= ?");

			pstmt.setString(1, rv_m_id);
			pstmt.setInt(2, startRow + size);
			pstmt.setInt(3, startRow);

			System.out.println("reviewDao_m_id:" + rv_m_id);
			System.out.println("reviewDao_startRow+size:" + startRow + size);
			System.out.println("reviewDao_startRow:" + startRow);

			rs = pstmt.executeQuery();
			List<Review> result = new ArrayList<Review>();
			while (rs.next()) {
				result.add(convertReview(rs));
			}
			return result;

		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	// 조회수증가 리턴
	public void increaseReadcnt(Connection conn, int no) throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("update review set rv_readcnt = rv_readcnt + 1 where rv_num =?")) {
			pstmt.setInt(1, no);
			pstmt.executeUpdate();
		}
	}

	// 값수정
	public int update(Connection conn, int rv_num, String title)
			throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("update review set rv_title = ? where rv_num = ?")) {
			pstmt.setString(1, title);
			pstmt.setInt(2, rv_num);
			return pstmt.executeUpdate();
		}

	}

	public int delete(Connection conn, int rv_num) throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("delete from review where rv_num = ?")

		) {
			pstmt.setInt(1, rv_num);
			return pstmt.executeUpdate();
		}
	}

	public int selectCountByKeyFiledWord(Connection conn, String keyField,
			String keyWord) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		
		String sql = "select count(*) from review rv, review_content rvc, Movie_info mv where rv.rv_num = rvc.rvc_rv_num and rv.rv_mv_num = mv.mv_num";
		if (keyWord != null && !keyWord.equals("")) {
			if(keyField.equals("total")){
				sql += " and (rvc_content like '%" + keyWord
						+ "%' or rv_title like '%" + keyWord + "%')";
			} else {
			sql += " and " + keyField + " LIKE '%" + keyWord + "%'";
			}
		}
		sql += " order by rv_num desc";
		
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}
		
	}

	public List<Review> selectSearch(Connection conn, int startRow, int size,
			String keyField, String keyWord, String reviewSort)
			throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		int rowcount = startRow + size - 1;

		String sql = "SELECT * FROM ( SELECT ROWNUM AS rnum, A.* FROM (select rv.*, rvc.*, mv.mv_title from  review rv, review_content rvc, Movie_info mv where rv.rv_num = rvc.rvc_rv_num and rv.rv_mv_num = mv.mv_num";
		if (keyWord != null && !keyWord.equals("")) {
			if (keyField.equals("total")) {
				sql += " and (rvc_content like '%" + keyWord
						+ "%' or rv_title like '%" + keyWord + "%')";
			} else {
				sql += " and " + keyField + " LIKE '%" + keyWord + "%'";
			}
		}

		if (reviewSort.equals("rv_num")) {
			sql += " ORDER BY rv_num DESC) A WHERE ROWNUM <= " + rowcount
					+ " ) WHERE RNUM >=" + startRow;
		} else { // 조회순
			sql += " ORDER BY " + reviewSort + " DESC) A WHERE ROWNUM <= "
					+ rowcount + " ) WHERE RNUM >=" + startRow;
		}

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			List<Review> result = new ArrayList<Review>();
			while (rs.next()) {
				result.add(convertReview(rs));
			}
			return result;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}
	}

}
