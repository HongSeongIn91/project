package preview.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;
import preview.service.ListPreviewService;
import preview.service.PreviewPage;

public class ListPreviewHandler implements CommandHandler {
	
	private ReadMovieService readMovieService = new ReadMovieService();
//	private ListPreviewService listService = new ListPreviewService();
	private ListPreviewService listService = new ListPreviewService(); 

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {

		int mv_num = Integer.parseInt(req.getParameter("mv_num"));
		
		String pageNoVal = req.getParameter("prePageNo");
		int prepageNo = 1;
		if(pageNoVal != null) {
			prepageNo = Integer.parseInt(pageNoVal);
		}
		
		// 영화 정보
		MovieData movieData = readMovieService.getMovie(mv_num, false);
		req.setAttribute("movieData", movieData);
		
		// 기대평 페이지
		PreviewPage previewPage = listService.getPreviewPage(prepageNo, mv_num);
		req.setAttribute("previewPage", previewPage);
		req.setAttribute("mv_num", mv_num);
		
		return "/WEB-INF/view/readMovie.jsp";
	}

}
