package preview.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import Connection.DBConnection;
import preview.dao.PreviewDao;
import preview.model.Preview;

public class ListPreviewService {

	private PreviewDao preDao = new PreviewDao();
	private int size = 10;
	
	public PreviewPage getPreviewPage(int pageNo, int mv_num) throws ClassNotFoundException, NamingException {
		
		try (Connection conn = DBConnection.getConnection()) {
			int total = preDao.selectCount(conn, mv_num);
			
			int startRow = (pageNo - 1) * size + 1;
			List<Preview> preview = preDao.select(conn, startRow, size, mv_num);
			return new PreviewPage(total, pageNo, size, preview);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
					
	}
	
	
}
