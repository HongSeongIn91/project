package movie.service;

public class MovieNotFoundException extends RuntimeException {

}
