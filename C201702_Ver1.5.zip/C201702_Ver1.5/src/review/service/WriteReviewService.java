package review.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.NamingException;

import review.dao.ReviewContentDao;
import review.dao.ReviewDao;
import review.model.Review;
import review.model.ReviewContent;
import member.dao.JdbcUtil;
import Connection.DBConnection;

public class WriteReviewService {

	private ReviewDao reviewDao = new ReviewDao();
	private ReviewContentDao contentDao = new ReviewContentDao();
	
	//사용자의 넘겨진 정보를 받아
	public Integer write(WriteRequest writeReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			//id,content,title을 갖고 전체 게시글에대한 정보를 생성하러감
			//등록일 카운트 등등
			Review review = toReview(writeReq);
			
			//넘겨와진정보를 담아 내용빼고담아 insert
			Review savedReview = reviewDao.insert(conn, review);
			if(savedReview == null) {
				throw new RuntimeException("fail to insert article");
			}
			
			//글제목과 내용을 담아 insert
			ReviewContent content = new ReviewContent(
					savedReview.getRv_num(), writeReq.getRv_content());
			ReviewContent savedContent = contentDao.insert(conn, content);
			
			if(savedContent == null) {
				throw new RuntimeException("fail to insert article_content");
			}
			
			conn.commit();
			
			return savedReview.getRv_num();//글번호 리턴
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (RuntimeException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

	//작성자, 제목, 내용 받아와서 날짜정보를 추가함
	//영화제목을같이 담아야함
	//일단임의로 1을 담음
	private Review toReview(WriteRequest writeReq) {
		Date now = new Date();

		return new Review(null, writeReq.getMv_num() ,writeReq.getRv_m_id(), now, writeReq.getRv_title(), 0, null);
	}
}
