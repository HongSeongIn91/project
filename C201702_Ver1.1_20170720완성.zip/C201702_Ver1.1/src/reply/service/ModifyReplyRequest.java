package reply.service;

import java.util.Map;

public class ModifyReplyRequest {

	private String userId;
	private int rp_num;
	private String rp_content;
	private int rp_rv_num;
	private int replyPageNo;
	
	public ModifyReplyRequest(String userId, int rp_num, String rp_content,
			int rp_rv_num, int replyPageNo) {
		super();
		this.userId = userId;
		this.rp_num = rp_num;
		this.rp_content = rp_content;
		this.rp_rv_num = rp_rv_num;
		this.replyPageNo = replyPageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getRp_num() {
		return rp_num;
	}

	public String getRp_content() {
		return rp_content;
	}

	public int getRp_rv_num() {
		return rp_rv_num;
	}

	public int getReplyPageNo() {
		return replyPageNo;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(rp_content == null || rp_content.trim().isEmpty()) {
			errors.put("rp_content", Boolean.TRUE);
		}
	}
}
