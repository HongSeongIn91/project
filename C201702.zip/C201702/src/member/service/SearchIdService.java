package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import member.dao.MemberDao;
import member.model.Member;

public class SearchIdService {

	private static MemberDao memberDao = new MemberDao();
	
	public Member searchId(String regnum, String email) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			
			Member member = memberDao.selectByRegnumEmail(conn, regnum, email);
			if (member == null) {
				throw new MemberNotFoundException();
			}
			return member;
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}

}
