package member.service;

public class NotMatchConfirmPasswordException extends Exception {

}
