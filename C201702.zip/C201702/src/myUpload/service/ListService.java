package myUpload.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import preview.model.Preview;
import reply.model.Reply;
import review.model.Review;
import Connection.DBConnection;
import myUpload.dao.PreviewDao;
import myUpload.dao.ReplyDao;
import myUpload.dao.ReviewDao;

public class ListService {

	private ReviewDao reviewDao = new ReviewDao();
	private PreviewDao previewDao = new PreviewDao();
	private ReplyDao replyDao = new ReplyDao();
	private int size = 10;
	
	public ReviewPage getReviewPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = reviewDao.selectCount(conn, m_id);
			List<Review> content = reviewDao.select(conn, (pageNum-1)*size, size, m_id);
			return new ReviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public PreviewPage getPreviewPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = previewDao.selectCount(conn, m_id);
			List<Preview> content = previewDao.select(conn, (pageNum-1)*size, size, m_id);
			return new PreviewPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ReplyPage getReplyPage(String m_id, int pageNum) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = replyDao.selectCount(conn, m_id);
			List<Reply> content = replyDao.select(conn, (pageNum-1)*size, size, m_id);
			return new ReplyPage(total, pageNum, size, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
