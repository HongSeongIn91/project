package myUpload.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import member.dao.JdbcUtil;
import review.model.ReviewContent;

public class ReviewContentDao {

	public ReviewContent selectByRvNum(Connection conn, int rvc_rv_num) throws SQLException {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"select * from review_content where rvc_rv_num = ?");
			pstmt.setInt(1, rvc_rv_num);
			rs = pstmt.executeQuery();
			ReviewContent content = null;
			
			if (rs.next()) {
				content = new ReviewContent(
						rs.getInt("rvc_rv_num"),
						rs.getString("rvc_content"));
			}
			return content;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

}
