package myUpload.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import preview.model.Preview;
import member.dao.JdbcUtil;

public class PreviewDao {

	public int selectCount(Connection conn, String pre_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try{
			pstmt = conn.prepareStatement("select count(*) from preview where pre_m_id = ?");
			pstmt.setString(1, pre_m_id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = rs.getInt(1);
				System.out.println("PreviewDao_rs.getInt(1):"+ rs.getInt(1));
				return result;
				
			} else {
				return result;
			}
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<Preview> select(Connection conn, int startRow, int size, String pre_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT * FROM PREVIEW WHERE PRE_M_ID= ? ORDER BY PRE_NUM DESC"
					+ ") A WHERE ROWNUM <= ?"
					+ ") WHERE RNUM >= ?"
					);
			
			pstmt.setString(1, pre_m_id);
			pstmt.setInt(2, startRow+size);
			pstmt.setInt(3, startRow);
			
			System.out.println("PreviewDao_pre_m_id:" +pre_m_id);
			System.out.println("PreviewDao_startRow+size:"+startRow+size);
			System.out.println("PreviewDao_startRow:" +startRow);
			
			rs = pstmt.executeQuery();
			List<Preview> result = new ArrayList<Preview>();
			while (rs.next()) {
				result.add(convertPreview(rs));
			}
			return result;
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private Preview convertPreview(ResultSet rs) throws SQLException {
		
		return new Preview(
				rs.getInt("pre_num"), 
				rs.getInt("pre_mv_num"),
				rs.getString("pre_m_id"),
				toDate(rs.getTimestamp("pre_regdate")),
				rs.getString("pre_content")
				);
	}

	private Date toDate(Timestamp timestamp) {
		
		return new Date(timestamp.getTime());
	}
}
