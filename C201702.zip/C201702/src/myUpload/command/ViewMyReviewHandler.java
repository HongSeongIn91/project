package myUpload.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.User;
import mvc.command.CommandHandler;
import myUpload.service.ListService;
import myUpload.service.ReviewPage;

public class ViewMyReviewHandler implements CommandHandler {

	/*private ListReviewService listService = new ListReviewService();*/
	private ListService listService = new ListService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		User user = (User)req.getSession().getAttribute("authUser");
		/*System.out.println(user.getId());*/
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		System.out.println(pageNo);
		ReviewPage reviewPage = listService.getReviewPage(user.getId(), pageNo);
		req.setAttribute("reviewPage", reviewPage);
		return "/WEB-INF/view/listMyReview.jsp";
	}

}
