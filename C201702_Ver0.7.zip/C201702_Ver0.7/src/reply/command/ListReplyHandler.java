package reply.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.command.CommandHandler;
import reply.service.ListReplyService;
import reply.service.ReplyPage;
import review.service.ReadReviewService;
import review.service.ReviewData;

public class ListReplyHandler implements CommandHandler {
	
	private ReadReviewService readReviewService = new ReadReviewService();
	private ListReplyService listService = new ListReplyService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		int rv_num = Integer.parseInt(req.getParameter("rv_num"));

		String pageNoVal = req.getParameter("replypageNo");
		int replypageNo = 1;
		if(pageNoVal != null) {
			replypageNo = Integer.parseInt(pageNoVal);
		}
		// 무비로그 
		ReviewData reviewData = readReviewService.getReview(rv_num, false);	
		req.setAttribute("reviewData", reviewData);
		
		
		// 댓글 페이지 
		ReplyPage replyPage = listService.getReplyPage(replypageNo, rv_num);
		req.setAttribute("replyPage", replyPage);
		req.setAttribute("rv_num", rv_num);
		
		System.out.println("리스트 리플 핸들러의 getCurrentPage : " + replyPage.getCurrentPage());
		System.out.println("리스트 리플 핸들러의 getStartPage : " + replyPage.getStartPage());
		System.out.println("리스트 리플 핸들러의 getEndPage : " + replyPage.getEndPage());
		
		return "/WEB-INF/view/readReview.jsp";
	}

}
