package auth.service;

public class LoginFailException extends RuntimeException {

}
