package review.service;

import java.util.Map;


public class ModifyRequest {

	//수정할 정보에 해당하는 내용데이터
	private String userId;
	private int rv_num;
	private String title;
	private String content;
	

	public ModifyRequest(String userId, int rv_num, String title, String content/*, int mv_num*/) {
		this.userId = userId;
		this.rv_num = rv_num;
		this.title = title;
		this.content = content;

	}

	public String getUserId() {
		return userId;
	}

	public int getRv_num() {
		return rv_num;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(title == null || title.trim().isEmpty()) {
			errors.put("title", Boolean.TRUE);
		}
		if(content == null || content.trim().isEmpty()) {
			errors.put("content", Boolean.TRUE);
		} 
	}

	
}
