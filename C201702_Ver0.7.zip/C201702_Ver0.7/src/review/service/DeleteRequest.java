package review.service;

import java.util.Map;

public class DeleteRequest {
	
	private String userId;
	private int rv_num;


	public DeleteRequest(String userId, int rv_num) {
		this.userId = userId;
		this.rv_num = rv_num;
		
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getRv_num() {
		return rv_num;
	}

	public void setRv_num(int rv_num) {
		this.rv_num = rv_num;
	}
	
	
	
	public void validate(Map<String, Boolean> errors) {
		if(userId == null || userId.trim().isEmpty()) {
			errors.put("userId", Boolean.TRUE);
		}
	}
}
