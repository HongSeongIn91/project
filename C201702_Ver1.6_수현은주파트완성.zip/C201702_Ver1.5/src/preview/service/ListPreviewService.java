package preview.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import myUpload.service.myPreview;
import myUpload.service.myPreviewPage;
import Connection.DBConnection;
import preview.dao.PreviewDao;
import preview.model.Preview;

public class ListPreviewService {

	private PreviewDao preDao = new PreviewDao();
	private int size = 10;
	private int mySize = 7;
	
	public PreviewPage getPreviewPage(int pageNo, int mv_num) throws ClassNotFoundException, NamingException {
		
		try (Connection conn = DBConnection.getConnection()) {
			int total = preDao.selectCount(conn, mv_num);//16
			System.out.println("total =>"+total);

			
			int startRow = (pageNo - 1) * size + 1;
			List<Preview> preview = preDao.select(conn, startRow, size, mv_num);
			System.out.println(" pageNo =>"+pageNo);
			return new PreviewPage(total, pageNo, size, preview);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
					
	}
	public myPreviewPage getMyPreviewPage(String m_id, int pageNo) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			int total = preDao.selectCountByMyId(conn, m_id);
			int startRow = (pageNo - 1) * mySize + 1;
			List<myPreview> content = preDao.selectByMyId(conn, startRow, mySize, m_id);
			return new myPreviewPage(total, pageNo, mySize, content);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
}
