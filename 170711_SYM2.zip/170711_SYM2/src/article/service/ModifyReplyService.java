package article.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.dao.ReplyDao;
import article.model.Reply;
import member.dao.JdbcUtil;

public class ModifyReplyService {

	private ReplyDao replyDao = new ReplyDao();

	public void modify(ModifyReplyRequest modReq) throws ClassNotFoundException, NamingException, SQLException {
		Connection conn = null;

		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);

			replyDao.update(conn, modReq.getReplyNumber(), modReq.getContent());

			conn.commit();

		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

}
