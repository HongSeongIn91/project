package article.command;

import java.io.IOException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.model.Reply;
import article.service.ArticleData;
import article.service.ArticleNotFoundException;
import article.service.DeleteReplyRequest;
import article.service.DeleteReplyService;
import article.service.ReadArticleService;
import article.service.ReplyListService;
import article.service.ReplyNotFoundException;
import article.service.ReplyPage;
import auth.service.User;
import mvc.command.CommandHandler;

public class DeleteReplyHandler implements CommandHandler {
	private static final String FORM_VIEW = "/WEB-INF/view/deleteReplyForm.jsp";
	
	private ReadArticleService readService = new ReadArticleService();
	private DeleteReplyService deleteService = new DeleteReplyService();
	private ReplyListService listService = new ReplyListService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws IOException, ClassNotFoundException, NamingException {
		
			
			User authUser = (User) req.getSession().getAttribute("authUser");
			
			String noVal = req.getParameter("replyNumber");		// 댓글 번호
			int no = Integer.parseInt(noVal);
			String noVal1 = req.getParameter("articleNum");		// 감상평 번호
			int articleNo = Integer.parseInt(noVal1);
			String noVal2 = req.getParameter("replypageNo");		// 댓글 페이지 번호
			int replypageNo = 1;
			//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
			if(noVal2 != null) {
				replypageNo = Integer.parseInt(noVal2);
			}
			

		
		DeleteReplyRequest delReq = new DeleteReplyRequest(authUser.getId(), no, articleNo, replypageNo);
		req.setAttribute("delReq", delReq);
	
		
		
		try {
				deleteService.delete(delReq);
				
				ArticleData articleData = readService.getArticle(articleNo, false);
				req.setAttribute("articleData", articleData);
				
				ReplyPage replyPage = listService.getListPage(replypageNo, articleNo);			// int pageNum, int articleNum
				req.setAttribute("replyPage", replyPage);
				
				
		
		return "/WEB-INF/view/readArticle.jsp";
		}catch (ReplyNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) throws IOException, ClassNotFoundException, NamingException {
		try {
			String noVal = req.getParameter("no");		// 댓글 번호
			int no = Integer.parseInt(noVal);
			String noVal1 = req.getParameter("articleNo");		// 감상평 번호
			int articleNo = Integer.parseInt(noVal1);		
			String noVal2 = req.getParameter("replypageNo");		// 댓글 페이지 번호
			int replypageNo = 1;
			//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
			if(noVal2 != null) {
				replypageNo = Integer.parseInt(noVal2);
			}

			
			req.setAttribute("no", no);		// 댓글 번호
			req.setAttribute("articleNo", articleNo);		// 감상평 번호
			req.setAttribute("replypageNo", replypageNo);		// 댓글 페이지 번호
			
			return FORM_VIEW;
		}catch (ReplyNotFoundException e) {
			 res.sendError(HttpServletResponse.SC_NOT_FOUND);
			 return null;
		}
	}

	
	

}
