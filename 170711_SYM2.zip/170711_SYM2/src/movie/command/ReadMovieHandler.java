package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticleContentNotFoundException;
import article.service.ArticleData;
import article.service.ArticleNotFoundException;

import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;
import preview.service.PreviewListService;
import preview.service.PreviewPage;

public class ReadMovieHandler implements CommandHandler {

	private ReadMovieService readService = new ReadMovieService();
	private PreviewListService previewService = new PreviewListService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {

		String noVal = req.getParameter("no");
		int movieNum = Integer.parseInt(noVal);
		
		try {
			// MovieData객체는 추후 기대평과 합치기위한 목적으로 남겨둔다
			MovieData movieData = readService.getArticle(movieNum, true);
			req.setAttribute("movieData", movieData);
			
			String prePageNoVal = req.getParameter("prePageNo");
			int pageNo = 1;
			if(prePageNoVal != null) {
				pageNo = Integer.parseInt(prePageNoVal);
			}
			
			PreviewPage prePage = previewService.getListPage(pageNo, movieNum);
//			PreviewPage prePage = previewService.getListPage(pageNum, previewNum)
			req.setAttribute("prePage", prePage);
			req.setAttribute("movieNum", movieNum);
			
			// 값을 가져와서 movieData객체에담아 readMovie.jsp로감
			return "/WEB-INF/view/readMovie.jsp";
			
		} catch (ArticleNotFoundException | ArticleContentNotFoundException e) {
			req.getServletContext().log("no movie", e);
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

}
