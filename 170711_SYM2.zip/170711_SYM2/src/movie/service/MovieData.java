package movie.service;

import java.util.List;

import movie.model.Movie;
import preview.model.Preview;

public class MovieData {

	private Movie movie;
	private Preview preview;
	private List<Preview> preList;
	
	public MovieData(Movie movie, Preview preview) {
		this.movie=movie;
		this.preview = preview;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Preview getPreview() {
		return preview;
	}

	public List<Preview> getPreList() {
		return preList;
	}
	
	
	
	
}
