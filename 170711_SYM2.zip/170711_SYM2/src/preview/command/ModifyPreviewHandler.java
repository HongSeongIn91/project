package preview.command;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticleData;
import article.service.ArticleNotFoundException;
import article.service.ModifyReplyRequest;
import article.service.ModifyReplyService;
import article.service.PermissionDeniedException;
import article.service.ReadArticleService;
import article.service.ReplyListService;
import article.service.ReplyPage;
import auth.service.User;
import movie.service.MovieData;
import movie.service.ReadMovieService;
import mvc.command.CommandHandler;
import preview.service.ModifyPreviewRequest;
import preview.service.ModifyPreviewService;
import preview.service.PreviewListService;
import preview.service.PreviewPage;

public class ModifyPreviewHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/modifyPreviewForm.jsp";

	private ReadMovieService readService = new ReadMovieService();
	private ModifyPreviewService preService = new ModifyPreviewService();
	private PreviewListService listService = new PreviewListService();
	

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res) throws Exception {
		if (req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ClassNotFoundException, NamingException {
		
		try {
			
			String noVal = req.getParameter("preNo");		// 기대평 번호
			int preNo = Integer.parseInt(noVal);
			String noVal1 = req.getParameter("movieNo");		// 영화 정보 번호
			int movieNo = Integer.parseInt(noVal1);		
			String noVal2 = req.getParameter("prePageNo");		// 기대평 페이지 번호
			int prePageNo = 1;
			//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
			if(noVal2 != null) {
				prePageNo = Integer.parseInt(noVal2);
			}

			req.setAttribute("preNo", preNo);		// 댓글 번호
			req.setAttribute("movieNo", movieNo);		// 감상평 번호
			req.setAttribute("prePageNo", prePageNo);		// 댓글 페이지 번호
			
			
			return FORM_VIEW;

		} catch (ArticleNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}


	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, IOException, SQLException  {

		
		User authUser = (User) req.getSession().getAttribute("authUser");
		
		String noVal = req.getParameter("preNo");		// 기대평 번호
		int preNo = Integer.parseInt(noVal);
		String noVal1 = req.getParameter("movieNo");		// 영화 정보 번호
		int movieNo = Integer.parseInt(noVal1);		
		String noVal2 = req.getParameter("prePageNo");		// 기대평 페이지 번호
		int prePageNo = 1;
		//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(noVal2 != null) {
			prePageNo = Integer.parseInt(noVal2);
		}

		
		
		ModifyPreviewRequest modReq = new ModifyPreviewRequest(authUser.getId(), preNo, req.getParameter("content"), movieNo, prePageNo);
		req.setAttribute("modReq", modReq);
	

		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		modReq.validate(errors);
		if (!errors.isEmpty()) {
			return FORM_VIEW;
		}

		try {
			preService.modify(modReq);
			
			// readArticle로 돌아왔을 때 감상평 데이터 보여줌
			MovieData movieData = readService.getArticle(movieNo, false);
			req.setAttribute("movieData", movieData);
			
			// readArticle로 돌아왔을 때 댓글 목록 보여줌
			PreviewPage prePage = listService.getListPage(prePageNo, movieNo);
			req.setAttribute("prePage", prePage);
			
			return "/WEB-INF/view/readMovie.jsp";
		} catch (ArticleNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		} catch (PermissionDeniedException e) {
			res.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
	}

	
}
