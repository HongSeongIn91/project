package preview.service;

import java.util.Map;

public class ModifyPreviewRequest {
	private String userId;
	private int preNumber;
	private String content;
	private int movieNo;
	private int prePageNo;
	
	public ModifyPreviewRequest(String userId, int preNumber, String content, int movieNo, int prePageNo) {
		this.userId = userId;
		this.preNumber = preNumber;
		this.content = content;
		this.movieNo = movieNo;
		this.prePageNo = prePageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getPreNumber() {
		return preNumber;
	}

	public String getContent() {
		return content;
	}

	public int getMovieNo() {
		return movieNo;
	}

	public int getPrePageNo() {
		return prePageNo;
	}
	
	public void validate(Map<String, Boolean> errors) {
		if(content == null || content.trim().isEmpty()) {
			errors.put("content", Boolean.TRUE);
		}
	}

}
