package preview.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.service.PermissionDeniedException;
import member.dao.JdbcUtil;
import preview.dao.PreviewDao;

public class DeletePreviewService {

	private PreviewDao preDao = new PreviewDao();

	public void delete(DeletePreviewRequest delReq) throws ClassNotFoundException, NamingException, SQLException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			preDao.delete(conn, delReq.getPreNumber());
			
			conn.commit();

		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}
}
