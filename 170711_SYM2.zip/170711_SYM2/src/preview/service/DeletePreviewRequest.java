package preview.service;

public class DeletePreviewRequest {
	private String userId;
	private int preNumber;
	private int movieNo;
	private int prePageNo;
	
	public DeletePreviewRequest(String userId, int preNumber, int movieNo, int prePageNo) {
		this.userId = userId;
		this.preNumber = preNumber;
		this.movieNo = movieNo;
		this.prePageNo = prePageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getPreNumber() {
		return preNumber;
	}

	public int getMovieNo() {
		return movieNo;
	}

	public int getPrePageNo() {
		return prePageNo;
	}

}
