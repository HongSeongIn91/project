package preview.service;

public class PreviewNotFoundException extends Exception {

}
