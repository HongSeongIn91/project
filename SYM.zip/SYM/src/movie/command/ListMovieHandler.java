package movie.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticlePage;
import movie.service.ListMovieService;
import movie.service.MoviePage;
import mvc.command.CommandHandler;

public class ListMovieHandler implements CommandHandler {

	private ListMovieService mlistServive = new ListMovieService();
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
	
		
		String pageNoVal = req.getParameter("pageNo");
		int pageNo = 1;
		//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(pageNoVal != null) {
			pageNo = Integer.parseInt(pageNoVal);
		}
		
		
		//ListArticleHandler를 이용하여 지정한 페이지번호에 해당 하는 게시글 데이터를 구한다
		//게시글 목록 데이터 보관데이터를 ArticlePage객체에 보관
		
		//ArticlePage articlePage = listService.getArticlepPage(pageNo);

		MoviePage moviePage = mlistServive.getMoviePage(pageNo);
		
		//ArticlePage 이용 JSp,에서 사용할수있도록 request 객체에 articlePage속성에 저장
		req.setAttribute("moviePage", moviePage);
		return "/WEB-INF/view/listMovie.jsp";
	}

}
