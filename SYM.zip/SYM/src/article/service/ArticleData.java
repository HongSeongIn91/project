package article.service;

import movie.model.Movie;
import article.model.Article;
import article.model.ArticleContent;

public class ArticleData {

	private Article article;
	private ArticleContent content;
	/*private Movie movie;*/
	
	public ArticleData(Article article, ArticleContent content
	/*		, Movie movie*/
			) {
		this.article = article;
		this.content = content;
	/*	this.movie=movie;*/
	}

	public Article getArticle() {
		return article;
	}

	public String getContent() {
		return content.getContent();
	}
/*
	public Movie getMovie() {
		return movie;
	}
	*/
	
	
}
