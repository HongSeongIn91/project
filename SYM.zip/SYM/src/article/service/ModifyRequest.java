package article.service;

import java.util.Map;


public class ModifyRequest {

	//수정할 정보에 해당하는 내용데이터
	private String userId;
	private int articleNumber;
	private String title;
	private String content;
	//private String mv_title;
	//private Movie movie;//수정할 폼에보여줄 영화제목
	/*private int mv_num;
	*/
/*	public int getMv_num() {
		return mv_num;
	}*/

	public ModifyRequest(String userId, int articleNumber, String title, String content/*, int mv_num*/) {
		this.userId = userId;
		this.articleNumber = articleNumber;
		this.title = title;
		this.content = content;
	/*	this.mv_num=mv_num;*/
	}

	public String getUserId() {
		return userId;
	}

	public int getArticleNumber() {
		return articleNumber;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}
	
	
	
	public void validate(Map<String, Boolean> errors) {
		if(title == null || title.trim().isEmpty()) {
			errors.put("title", Boolean.TRUE);
		}
	}

	
}
