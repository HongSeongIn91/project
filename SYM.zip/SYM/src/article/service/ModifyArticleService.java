package article.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import member.dao.JdbcUtil;
import Connection.DBConnection;
import article.dao.ArticleContentDao;
import article.dao.ArticleDao;
import article.model.Article;

public class ModifyArticleService {

	//게시물과 게시컨텐츠 객체 생성
	private ArticleDao articleDao = new ArticleDao();
	private ArticleContentDao contentDao = new ArticleContentDao();
	
	public void modify(ModifyRequest modReq) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			//게시글 번호에 해당하는 값 가져와
			Article article = articleDao.selectById(conn, modReq.getArticleNumber());
			//해당 번호를 가진 게시글이 존재하지않으면 ArticleNotFoundException 익셉션 처리
			if(article == null) {
				throw new ArticleNotFoundException();
			}//수정할 사용자가 해당 게시글을 수정할 수 있는지 검사?.. 이건다른 사용자도 수정할수있다는 가정이있다는뜻이네
			if(!canModify(modReq.getUserId(), article)) {
				throw new PermissionDeniedException();
			}
			//제목수정
			articleDao.update(conn, modReq.getArticleNumber(), modReq.getTitle());
			//내용수정
			contentDao.update(conn, modReq.getArticleNumber(), modReq.getContent());
			//커밋
			conn.commit();
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

	//수정을 요청하는 사용자와 해당 게시글의 사용자와 아이디가 동일한지 확인
	private boolean canModify(String modifyingUserId, Article article) {
		
//		return article.getRv_m_id().getId().equals(modifyingUserId);
		return article.getRv_m_id().equals(modifyingUserId);
	}
}
