package article.service;

import java.util.List;

import article.model.Article;
//게시글 목록을 제공하는 서비스 클래스를 구현
//게시글 데이터와 페이징 관련 정보를담을 ArticlePage

public class ArticlePage {
	
	
	private List<Article> content; // 화면에 출력할 게시글 목록을 보관
	private int totalPages; //전체페이지개수를 보관
	private int startPage; //화면하단에 보여줄 페이지 이동링크의 시작번호와 끝번호
	private int endPage;
	private int currentPage; // 사용자가 요청한 페이지번호를 보관
	private int total; //전체 게시글 개수보관38
	private int startRow;//(1-1)*10+1
	private int startNum;//38
	

	//new ArticlePage(total, pageNum, size, content);
	public ArticlePage(int total, int currentPage, int size, List<Article> content) {
		this.total = total;
		this.currentPage = currentPage;
		this.content = content;
		this.startRow=(currentPage- 1) * size + 1;
		this.startNum=total - startRow + 1; // 38-1+1; 38;
		
		if(total == 0) {
			totalPages = 0;
			startPage = 0;
			endPage = 0;
		} else {
			
			//55개/10=5
			totalPages = total/size; //전체개수/10
			if(total % size > 0) { //나머지가 0보다 크면 페이지를 +1함
				totalPages++;//6
			}
			//modVal 화면하단에 보여줄 페이지 이동링크의 시작페이지 번호를 구함 
			int modVal = currentPage % 5; //5개씩보여줄라나보다 5%5 나머지=0 , 10인경우 0
			startPage = currentPage / 5 * 5 + 1;//5/5*5+1;=>6 (6)10/5*5+1 11
			if (modVal == 0) startPage -= 5; // startPage = startPage-5;//6-5=1 11-5=6;
			
			endPage = startPage + 4;//
			if (endPage > totalPages) endPage = totalPages;
		}
	}

	public int getStartRow() {
		return startRow;
	}

	public void setContent(List<Article> content) {
		this.content = content;
	}

	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}

	public int getStartNum() {
		return startNum;
	}

	public void setStartNum(int startNum) {
		this.startNum = startNum;
	}
	public int getTotal() {
		return total;
	}
	
	public boolean hasNoArticles() {
		return total == 0;
	}
	
	public boolean hasArticles() {
		return total > 0;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public List<Article> getContent() {
		return content;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public int getStartPage() {
		return startPage;
	}

	public int getEndPage() {
		return endPage;
	}
	
	
}
