package article.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import member.dao.JdbcUtil;
import movie.model.Movie;
import article.model.Article;
import article.model.Writer;

public class ArticleDao {

	// 글 내용삽입
	public Article insert(Connection conn, Article article) throws SQLException {
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn
					.prepareStatement("insert into review "
							+ "(rv_num, rv_mv_num, rv_m_id, rv_regdate, rv_title, rv_readcnt) "
							+ "values (review_sequence.nextval, ?, ?, ?, ?, 0)");
			//게시물번호,영화번호,글쓴이,쓴날짜,제목,조회수
			//Article>Writer요청정보에담긴,getId를가져온다
			
			//pstmt.setString(1, article.getWriter().getId());
			pstmt.setInt(1, article.getRv_mv_num());
			pstmt.setString(2, article.getRv_m_id());
			
			// pstmt.setString(2, article.getWriter().getName());
			pstmt.setTimestamp(3, toTimestamp(article.getRv_regdate()));
			pstmt.setString(4, article.getRv_title());
			// pstmt.setTimestamp(5, toTimestamp(article.getModifiedDate()));
			// 인설트 결과 받아옴
			int insertedCount = pstmt.executeUpdate();

			// 인설트개수가 0보다 크면
			if (insertedCount > 0) {
				stmt = conn.createStatement();
				// 그 최근 번호를 받아서select
				rs = stmt
						.executeQuery("select Review_SEQUENCE.CURRVAL from review");
				if (rs.next()) {
					//객체에 담아
					Integer newNum = rs.getInt(1);//최근번호 알려줌
					return new Article(newNum, article.getRv_mv_num(), article.getRv_m_id(),
							article.getRv_regdate(), article.getRv_title(), 0,null);

				}
			}
			return null;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
			JdbcUtil.close(pstmt);

		}
	}

	private Timestamp toTimestamp(Date date) {

		return new Timestamp(date.getTime());
	}

	public int selectCount(Connection conn) throws SQLException {
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select count(*) from review");
			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}
	}

	// 페이지에 대한 리스트출력 21,10
	public List<Article> select(Connection conn, int startRow, int size)
			throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			// 페이징처리
			pstmt = conn.prepareStatement("SELECT * FROM ( SELECT ROWNUM AS rnum, A.* "
					+ "FROM (select rv.*, mv.mv_title "
						+ "from review rv, movie_info mv "
						+ "where rv.rv_mv_num=mv.mv_num ORDER BY rv.rv_num DESC ) A "
						+ "WHERE ROWNUM <= ?)"
				+ " WHERE RNUM >=?");
			/*
			"SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT * FROM review ORDER BY rv_num DESC"
					+ ") A WHERE ROWNUM <= ?" + ") WHERE RNUM >= ?");
			 */
			pstmt.setInt(1, startRow + size - 1);
			// pstmt.setInt(1, startRow + size); //21+10-1 -> 30
			pstmt.setInt(2, startRow); // 21
			rs = pstmt.executeQuery();

			// 목록리스트를 Arraylist에 담는다
			// result 객체리스트를 생성한다
			List<Article> result = new ArrayList<Article>();
			while (rs.next()) {
				result.add(convertArticle(rs));
			}
			return result;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	private static Article convertArticle(ResultSet rs) throws SQLException {
		// 작성자 정보와 작성글번호를 디비에서 받아와서  더해서 아티글로 리턴
		return new Article(rs.getInt("rv_num"),
				rs.getInt("rv_mv_num"),
				rs.getString("rv_m_id"),
				//new Writer(rs.getString("rv_m_id")),
				toDate(rs.getTimestamp("rv_regdate")),
				rs.getString("rv_title"),
				rs.getInt("rv_readcnt"), new Movie(rs.getString("mv_title")));
				
				

	}

	private static Date toDate(Timestamp timestamp) {

		return new Date(timestamp.getTime());
	}

	// 게시물 번호를 가지고 selelct 처리 해서
	// converArticle페이지에서 결과 에대한 정보를 article객체에 담아서 리턴
	public Article selectById(Connection conn, int no) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select rv.*, mv.mv_title "
					+ "from review rv, movie_info mv "
					+ "where  rv.rv_mv_num=mv.mv_num and rv.rv_num = ?");
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			Article article = null;
			if (rs.next()) {
				article = convertArticle(rs);
			}
			return article;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	// 조회수증가 리턴
	public void increaseReadCount(Connection conn, int no) throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("update review set rv_readcnt = rv_readcnt + 1 where rv_num =?")) {
			pstmt.setInt(1, no);
			pstmt.executeUpdate();
		}
	}

	// 값수정
	public int update(Connection conn, int no, String title)
			throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("update review set rv_title = ? where rv_num = ?")) {
			pstmt.setString(1, title);
			pstmt.setInt(2, no);
			return pstmt.executeUpdate();
		}

	}
	public int delete(Connection conn, int no) throws SQLException {
		try(PreparedStatement pstmt = conn.prepareStatement("delete from review where rv_num = ?")
				
		) {
			pstmt.setInt(1, no);
			return pstmt.executeUpdate();
		}
	}

}
