package article.command;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.model.Writer;
import article.service.ArticleData;
import article.service.WriteArticleService;
import article.service.WriteRequest;
import auth.service.User;
import movie.model.Movie;
import movie.service.ListMovieService;
import movie.service.MovieData;
import movie.service.MoviePage;
import mvc.command.CommandHandler;

//
public class WriteArticleHandler implements CommandHandler {
	private static final String FORM_VIEW = "/WEB-INF/view/newArticleForm.jsp";
	private ListMovieService mlistServive = new ListMovieService();
	private WriteArticleService writeService = new WriteArticleService();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if(req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException {
		
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		//사용자정보
		//getid만있음
//		id, password
		User user = (User)req.getSession(false).getAttribute("authUser");
		
		//글쓴정보 담아
		//req에는 제목이랑, 내용이있음 //writer, title, content
		WriteRequest writeReq = createWriteRequest(user, req);//사용자와 제목, 내용을 담은 것을
		writeReq.validate(errors);
		
		if(!errors.isEmpty()) {
			return FORM_VIEW;
		}
		
		//입력된 그 정보로 이용해서 서비스실행
		int newArticleNo = writeService.write(writeReq);
		req.setAttribute("newArticleNo", newArticleNo);
		
		
		return "/WEB-INF/view/newArticleSuccess.jsp";
	}
	

	
	private WriteRequest createWriteRequest(User user, HttpServletRequest req) {
		//post로 넘어온 그정보를 각각 담아
		return new WriteRequest(
				//new Writer(user.getId()),//user객체에 담인 계정정보를 writer에 담아
				user.getId(),
				req.getParameter("title"), 
				Integer.parseInt(req.getParameter("mv_num")),
				req.getParameter("content"));
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) throws Exception {

		//영화번호를 가지고 폼에보여줘야함
		MoviePage moviePage = mlistServive.getMovie();
		req.setAttribute("moviePage",moviePage);
		return FORM_VIEW;
	}

}
