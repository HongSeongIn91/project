package article.command;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticleData;
import article.service.ArticleNotFoundException;
import article.service.DeleteArticleService;
import article.service.DeleteRequest;
import article.service.ReadArticleService;
import auth.service.User;
import mvc.command.CommandHandler;

public class DeleteArticleHandler implements CommandHandler {
	private static final String FORM_VIEW = "/WEB-INF/view/deleteForm.jsp";

	private ReadArticleService readService = new ReadArticleService();
	private DeleteArticleService deleteService = new DeleteArticleService();
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if(req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processForm(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, IOException {
		
		String noVal = req.getParameter("no");
		int no = Integer.parseInt(noVal);
		
	/*	String noVal1= req.getParameter("mno");
		int mno=Integer.parseInt(noVal1);
*/
		req.setAttribute("no",no);
		/*req.setAttribute("mno", mno);*/
		return FORM_VIEW;
	}
	
	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, NamingException, IOException {
		try {

			User authUser = (User)req.getSession().getAttribute("authUser");
			
			String noVal = req.getParameter("articleNumber");
			int no = Integer.parseInt(noVal);
		/*	String noVal1 = req.getParameter("mv_num");
			int mno = Integer.parseInt(noVal1);
		*/	
			ArticleData articleData = readService.getArticle(no, false/*, mno*/);
			if(!canDelete(authUser, articleData)) {
				res.sendError(HttpServletResponse.SC_FORBIDDEN);
				return null;
			}
			DeleteRequest delReq = new DeleteRequest(authUser.getId(), no);
			req.setAttribute("delReq", delReq);
			deleteService.delete(delReq);
			return "/WEB-INF/view/deleteSuccess.jsp";
		} catch (ArticleNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

	private boolean canDelete(User authUser, ArticleData articleData) {
		String writerId = articleData.getArticle().getRv_m_id();
		return authUser.getId().equals(writerId);
	}
	
	
}


















