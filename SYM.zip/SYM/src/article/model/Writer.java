package article.model;

public class Writer {

	//게시글 작성자 정보를 담는 클래스
	private String id;
		
	//들어오는 형이 Writer인데, 리턴형이 String 임
	public Writer(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}


	
}
