package article.model;

import java.util.Date;

import movie.model.Movie;
//DTO
public class Article {
	
	private Integer rv_num;
	private int rv_mv_num;
	private String rv_m_id;
	//private Writer writer;
	private Date rv_regdate;
	private String rv_title;
	private int rv_readcnt;
	private Movie movie;
	
	


	//public Article(Integer rv_num, int rv_mv_num, Writer writer,
	public Article(Integer rv_num, int rv_mv_num, String rv_m_id,
			 Date rv_regdate, String rv_title, int rv_readcnt, Movie movie) {
		this.rv_num = rv_num;
		this.rv_mv_num = rv_mv_num;
	//	this.writer = writer;
		this.rv_m_id=rv_m_id;
		this.rv_regdate = rv_regdate;
		this.rv_title = rv_title;
		this.rv_readcnt = rv_readcnt;
		this.movie=movie;
	}

	public Article(Integer rv_num, int rv_mv_num, String rv_m_id,
			 Date rv_regdate, String rv_title, int rv_readcnt) {
		this.rv_num = rv_num;
		this.rv_mv_num = rv_mv_num;
	//	this.writer = writer;
		this.rv_m_id=rv_m_id;
		this.rv_regdate = rv_regdate;
		this.rv_title = rv_title;
		this.rv_readcnt = rv_readcnt;
	
	}

	public Article(Integer rv_num, int rv_mv_num) {
		this.rv_num = rv_num;
		this.rv_mv_num = rv_mv_num;
	}

	public Integer getRv_num() {
		return rv_num;
	}

	public int getRv_mv_num() {
		return rv_mv_num;
	}

	/*public Writer getWriter() {
		return writer;
	}*/
	public String getRv_m_id() {
		return rv_m_id;
	}
	
	public Date getRv_regdate() {
		return rv_regdate;
	}

	public String getRv_title() {
		return rv_title;
	}

	public int getRv_readcnt() {
		return rv_readcnt;
	}

	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	
	
/*원본
	private Integer number;
	private Writer writer;
	private String title;
	private Date regDate;
	private Date modifiedDate;
	private int readCount;
	
	public Article(Integer number, Writer writer, String title, Date regDate, Date modifiedDate, int readCount) {
		this.number = number;
		this.writer = writer;
		this.title = title;
		this.regDate = regDate;
		this.modifiedDate = modifiedDate;
		this.readCount = readCount;
	}

	public Integer getNumber() {
		return number;
	}

	public Writer getWriter() {
		return writer;
	}

	public String getTitle() {
		return title;
	}

	public Date getRegDate() {
		return regDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public int getReadCount() {
		return readCount;
	}*/
	
	
}
