package article.service;

import java.util.Map;

import article.model.Writer;

public class WriteRequest {

	// private Writer writer;
	private String rv_m_id;
	private String rv_title;
	private String rv_content;

	public WriteRequest(String rv_m_id, String rv_title, String rv_content) {
	//	 public WriteRequest(Writer writer, String rv_title, String rv_content) {
	//	 this.writer = writer;
		this.rv_m_id = rv_m_id;
		this.rv_title = rv_title;
		this.rv_content = rv_content;
	}

	public String getRv_content() {
		return rv_content;
	}

	
	/* public Writer getWriter() { return writer; }*/
	 
	public String getRv_m_id() {
		return rv_m_id;
	}

	public String getRv_title() {
		return rv_title;
	}

	/*
	 * public void validate(Map<String, Boolean> errors) { if(rv_title == null
	 * || rv_title.trim().isEmpty()) { errors.put("rv_title", Boolean.TRUE); } }
	 */
}
