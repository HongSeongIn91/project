package preview.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import preview.model.Preview;
import member.dao.JdbcUtil;
import movie.model.Movie;
import myUpload.service.myPreview;

public class PreviewDao {

	public int selectCountByMyId(Connection conn, String pre_m_id)
			throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			pstmt = conn
					.prepareStatement("select count(*) from preview where pre_m_id = ?");
			pstmt.setString(1, pre_m_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1);
				System.out.println("PreviewDao_rs.getInt(1):" + rs.getInt(1));
				return result;

			} else {
				return result;
			}

		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}

	public List<myPreview> selectByMyId(Connection conn, int startRow,
			int size, String pre_m_id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(
					"SELECT * FROM ("
					+ "SELECT ROWNUM AS rnum, A.* FROM ("
					+ "SELECT pre.*, mv.mv_title " 
					+ "FROM movie_info mv "
					+ "INNER JOIN preview pre "
					+ "ON (mv.mv_num = pre.pre_mv_num) "
					+ "WHERE pre.pre_m_id = ? ORDER BY pre.pre_regdate DESC) A "
					+ "WHERE ROWNUM <= ?) " + "WHERE RNUM >= ?"
					);
			
			pstmt.setString(1, pre_m_id);
			pstmt.setInt(2, startRow+size);
			pstmt.setInt(3, startRow);
			
			rs = pstmt.executeQuery();
			List<myPreview> result = new ArrayList<myPreview>();
			while (rs.next()) {
				result.add(convertMyPreview(rs));
			}
			return result;
			
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}



	private myPreview convertMyPreview(ResultSet rs) throws SQLException {

		return new myPreview(rs.getInt("pre_num"), rs.getInt("pre_mv_num"),
				rs.getString("pre_m_id"),
				toDate(rs.getTimestamp("pre_regdate")),
				rs.getString("pre_content"),
				new Movie(rs.getString("mv_title")));

	}

	private Date toDate(Timestamp timestamp) {

		return new Date(timestamp.getTime());
	}

	public int selectCount(Connection conn, int mv_num) throws SQLException {

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn
					.prepareStatement("select count(*) from preview where pre_mv_num = ?");
			pstmt.setInt(1, mv_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt(1);
			}
			return 0;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}

	}

	public List<Preview> select(Connection conn, int startRow, int size,
			int mv_num) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {

			pstmt = conn
					.prepareStatement("select * from (select rownum as rnum, A.* from"
							+ " (select preview.* from preview, movie_info where preview.pre_mv_num = movie_info.mv_num and preview.pre_mv_num = ? order by pre_num )"
							+ " A where rownum <= ?) where rnum >= ?");
			pstmt.setInt(1, mv_num);
			pstmt.setInt(2, startRow + size - 1);
			pstmt.setInt(3, startRow);

			rs = pstmt.executeQuery();

			List<Preview> preList = new ArrayList<Preview>();
			while (rs.next()) {
				preList.add(convertPreview(rs));
			}
			return preList;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}


	private Preview convertPreview(ResultSet rs) throws SQLException {

		return new Preview(rs.getInt("pre_num"), rs.getInt("pre_mv_num"),
				rs.getString("pre_m_id"),
				toDate(rs.getTimestamp("pre_regdate")),
				rs.getString("pre_content"));
	}
	public Preview insert(Connection conn, Preview preview) throws SQLException {
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			pstmt = conn
					.prepareStatement("insert into preview (pre_num, pre_mv_num, pre_m_id, pre_regdate, pre_content) "
							+ "values (preview_sequence.nextval,?,?,?,?)");
			pstmt.setInt(1, preview.getPre_mv_num());
			pstmt.setString(2, preview.getPre_m_id());
			pstmt.setTimestamp(3, toTimestamp(preview.getPre_regdate()));
			pstmt.setString(4, preview.getPre_content());

			int insertedCount = pstmt.executeUpdate();

			if (insertedCount > 0) {
				stmt = conn.createStatement();
				rs = stmt
						.executeQuery("select preview_sequence.currval from preview");

				if (rs.next()) {
					Integer newNum = rs.getInt(1);

					return new Preview(newNum, preview.getPre_mv_num(),
							preview.getPre_m_id(), preview.getPre_regdate(),
							preview.getPre_content());
				}
			}
			return null;
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
			JdbcUtil.close(pstmt);
		}

	}

	private Timestamp toTimestamp(Date pre_regdate) {

		return new Timestamp(pre_regdate.getTime());
	}

	public int update(Connection conn, int pre_num, String pre_content)
			throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("update preview set pre_content = ? where pre_num = ?")) {
			pstmt.setString(1, pre_content);
			pstmt.setInt(2, pre_num);
			return pstmt.executeUpdate();
		}

	}

	public int delete(Connection conn, int pre_num) throws SQLException {
		try (PreparedStatement pstmt = conn
				.prepareStatement("delete from preview where pre_num = ?")) {
			pstmt.setInt(1, pre_num);
			return pstmt.executeUpdate();
		}

	}

}
