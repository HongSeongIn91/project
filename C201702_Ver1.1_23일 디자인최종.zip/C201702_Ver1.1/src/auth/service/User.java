package auth.service;

public class User {

	private String id;
	private String email;
	private String phone;
	
	public User(String id, String email, String phone) {
		this.id = id;
		this.email = email;
		this.phone = phone;
	}

	public String getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}
	
	public String getPhone() {
		return phone;
	}

}
