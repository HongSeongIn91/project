package member.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import member.dao.JdbcUtil;
import member.dao.MemberDao;

public class WithdrawService {

	private MemberDao memberDao = new MemberDao();
	
	public void withdraw(String m_id) throws ClassNotFoundException, NamingException {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
		
			memberDao.delete(conn, m_id);
	
			conn.commit();
				
		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} finally {
			JdbcUtil.close(conn);
		}
	}

}
