package article.service;

public class WirteReplyRequest {
	
	private String rp_m_id;
	private String rp_content;
	private int rp_rv_num;
	
	public WirteReplyRequest(String rp_m_id, String rp_content, int rp_rv_num) {
		this.rp_m_id = rp_m_id;
		this.rp_content = rp_content;
		this.setRp_rv_num(rp_rv_num);
	}



	public String getRp_m_id() {
		return rp_m_id;
	}

	public String getRp_content() {
		return rp_content;
	}



	public int getRp_rv_num() {
		return rp_rv_num;
	}



	public void setRp_rv_num(int rp_rv_num) {
		this.rp_rv_num = rp_rv_num;
	}



}
