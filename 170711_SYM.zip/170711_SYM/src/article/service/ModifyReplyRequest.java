package article.service;

import java.util.Map;

public class ModifyReplyRequest {
	private String userId;
	private int replyNumber;
	private String content;
	private int articleNo;
	private int replypageNo;

	public ModifyReplyRequest(String userId, int replyNumber, String content, int articleNo, int replypageNo) {
		this.userId = userId;
		this.replyNumber = replyNumber;
		this.content = content;
		this.articleNo = articleNo;
		this.replypageNo = replypageNo;
	}

	public String getUserId() {
		return userId;
	}

	public int getReplyNumber() {
		return replyNumber;
	}

	public String getContent() {
		return content;
	}
	
	public int getArticleNo() {
		return articleNo;
	}

	public int getReplypageNo() {
		return replypageNo;
	}

	public void validate(Map<String, Boolean> errors) {
		if(content == null || content.trim().isEmpty()) {
			errors.put("content", Boolean.TRUE);
		}
	}

}
