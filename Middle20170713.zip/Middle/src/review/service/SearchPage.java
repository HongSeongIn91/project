package review.service;

import java.util.List;

import review.model.Review;



public class SearchPage {

	private List<Review> content; 
	private int totalPages;
	private int startPage;
	private int endPage;
	private int currentPage;
	private int total;
	//4, 1, 10, 게시물정보4개
	public SearchPage(int total, int currentPage, int size, List<Review> content) {
		this.total = total;
		this.currentPage = currentPage;
		this.content = content;
		
		if(total == 0) {
			totalPages = 0;
			startPage = 0;
			endPage = 0;
		} else {
			totalPages = total/size;//4/10 
			if(total % size > 0) { //2%10>0
				totalPages++;
			}
			
			int modVal = currentPage % 5; //5개씩보여줄라나보다 5%5 나머지=0 , 10인경우 0
			startPage = currentPage / 5 * 5 + 1;//5/5*5+1;=>6 (6)10/5*5+1 11
			if (modVal == 0) startPage -= 5; // startPage = startPage-5;//6-5=1 11-5=6;
			
			endPage = startPage + 4;//
			if (endPage > totalPages) endPage = totalPages;
		}
	}
	
	public void setContent(List<Review> content) {
		this.content = content;
	}
	
	public int getTotal() {
		return total;
	}
	
	public boolean hasNoReviews() {
		return total == 0;
	}
	
	public boolean hasReviews() {
		return total > 0;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public List<Review> getContent() {
		return content;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public int getStartPage() {
		return startPage;
	}

	public int getEndPage() {
		return endPage;
	}
	
	
}
