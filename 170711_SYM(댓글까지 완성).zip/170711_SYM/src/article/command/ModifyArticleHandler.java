package article.command;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticleData;
import article.service.ArticleNotFoundException;
import article.service.ModifyArticleService;
import article.service.ModifyRequest;
import article.service.PermissionDeniedException;
import article.service.ReadArticleService;
import auth.service.User;
import mvc.command.CommandHandler;
//이건 좀 복잡함 
// 왜냐 get인 경우에도 수정할 데이터(기존데이터 내용)을 폼에 ㅊ ㅐ워서 보여줘야함 processForm
// post는 수정할 정보 담아 

public class ModifyArticleHandler implements CommandHandler {

	private static final String FORM_VIEW = "/WEB-INF/view/modifyForm.jsp";

	private ReadArticleService readService = new ReadArticleService();
	private ModifyArticleService modifyService = new ModifyArticleService();

	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		if (req.getMethod().equalsIgnoreCase("GET")) {
			return processForm(req, res);
		} else if (req.getMethod().equalsIgnoreCase("POST")) {
			return processSubmit(req, res);
		} else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, NamingException, IOException {

		User authUser = (User) req.getSession().getAttribute("authUser");

		
		String noVal = req.getParameter("articleNumber");
		int no = Integer.parseInt(noVal);
	
		// 요청 파라미터와 현재 사용자 정보를 이용해서 ModifyRequest 객체를 생성한다.
		ModifyRequest modReq = new ModifyRequest(authUser.getId(), no,
				req.getParameter("title"), req.getParameter("content"));
		req.setAttribute("modReq", modReq);

		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		modReq.validate(errors);
		if (!errors.isEmpty()) {
			return FORM_VIEW;
		}
		try {
			modifyService.modify(modReq);
			return "/WEB-INF/view/modifySuccess.jsp";
		} catch (ArticleNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		} catch (PermissionDeniedException e) {
			res.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}

	}

	// 수정전의 데이터 기존데이터를 불러와 보여줘야한다
	private String processForm(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, NamingException, IOException {

		try {
			String noVal = req.getParameter("no");
			int no = Integer.parseInt(noVal);

			// 게시글을 읽어온다 대신 조회는 증가하지않음
			//작성자 정보와 글 정보를 다 가져옴 
			ArticleData articleData = readService.getArticle(no, false);
			
			System.out.println("modifyArticleHandler form 아이디 : " + articleData.getArticle().getRv_m_id());
			
			// 로그인한 사용자정보를 불러온다
			User authUser = (User) req.getSession().getAttribute("authUser");
			
	

			// 유저와 그게시글의 작성자와 비교하는 매소드
			if (!canModify(authUser, articleData)) {
				res.sendError(HttpServletResponse.SC_FORBIDDEN);
				return null;
			}
			// 위모두가 잘 통과했다는뜻은 => 수정요청하는 사용자와 게시글작성자와 동일하다는뜻임
			ModifyRequest modReq = new ModifyRequest(authUser.getId(), no,
					articleData.getArticle().getRv_title(),
					articleData.getContent());

			// 수정정보를 담아 폼에보여준다!
			req.setAttribute("modReq", modReq);
			return FORM_VIEW;
		} catch (ArticleNotFoundException e) {
			res.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
	}

	// authUser 세션에 담긴 사용자 아이디와 수정요청하는 글의 작성자가 아이디가 동일한지 확인
	// return 1이면 같음 0이면 같지않음 ;
	private boolean canModify(User authUser, ArticleData articleData) {
	//	String writerId = articleData.getArticle().getWriter().getId();
		String writerId = articleData.getArticle().getRv_m_id();
		return authUser.getId().equals(writerId);
	}

}
