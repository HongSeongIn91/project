package article.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import article.service.ArticleData;
import article.service.ReadArticleService;
import article.service.ReplyListService;
import article.service.ReplyPage;
import article.service.WriteReplyService;
import article.service.WriteReplyRequest;
import auth.service.User;
import mvc.command.CommandHandler;

public class WriteReplyHandler  implements CommandHandler{
	private static final String FORM_VIEW = "/WEB-INF/view/readArticle.jsp";
	private WriteReplyService replyService = new WriteReplyService();
	private ReadArticleService readService = new ReadArticleService();
	private ReplyListService listService = new ReplyListService();
	

	
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		Map<String, Boolean> errors = new HashMap<String, Boolean>();
		req.setAttribute("errors", errors);
		
		User user = (User)req.getSession(false).getAttribute("authUser");
		
		String noVal1 = req.getParameter("articleNo");		// 감상평 번호
		int articleNo = Integer.parseInt(noVal1);
		int replypageNo = 1;
		/*String noVal2 = req.getParameter("replypageNo");		// 댓글 페이지 번호
*/		/*//페이지번호가 넘겨진게있다면 그걸 페이지번호로한다
		if(noVal2 != null) {
			replypageNo = Integer.parseInt(noVal2);
		}*/
		
		System.out.println("--------------------------------");
		System.out.println("noVal1 : " + noVal1);
		System.out.println("articleNo : " + articleNo);
		System.out.println("content : " +  req.getParameter("content"));
		
		WriteReplyRequest replyReq = createWirteReplyRequest(user, req);
		
		
		
		int articleNo1 = replyService.write(replyReq);
		req.setAttribute("articleNo", articleNo1);
		
		ArticleData articleData = readService.getArticle(articleNo, false);
		req.setAttribute("articleData", articleData);
		
		ReplyPage replyPage = listService.getListPage(replypageNo, articleNo);
		req.setAttribute("replyPage", replyPage);
		
		return FORM_VIEW;
	}
	private WriteReplyRequest createWirteReplyRequest(User user, HttpServletRequest req) {
		System.out.println("WriteReplyRequest 밑에 user.getId()->" + user.getId());
		System.out.println("WriteReplyRequest createWirteReplyRequest ->content : " + req.getParameter("content"));
		System.out.println("WriteReplyRequest articleNo->" + Integer.parseInt(req.getParameter("articleNo")));
		
		return new WriteReplyRequest(
				user.getId(), req.getParameter("content"), Integer.parseInt(req.getParameter("articleNo")));
				
	}
	
}
