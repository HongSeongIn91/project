package article.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import com.sun.org.apache.bcel.internal.generic.Select;

import Connection.DBConnection;
import article.dao.ArticleContentDao;
import article.dao.ArticleDao;
import article.dao.ReplyDao;
import article.model.Article;
import article.model.ArticleContent;
import article.model.Reply;

public class ReadArticleService {

	//게시글 읽기 클래스
	//콘텐츠와 나머지정보가 담긴 객체를 합침
	private ArticleDao articleDao = new ArticleDao();
	private ArticleContentDao contentDao = new ArticleContentDao();
	private ReplyDao replyDao = new ReplyDao();
	private int size = 10;

	
	public ArticleData getArticle(int articleNum, boolean increaseReadCount) throws ClassNotFoundException, NamingException {
		try (Connection conn = DBConnection.getConnection()) {
			Article article = articleDao.selectById(conn, articleNum);
			//게시글 데이터가 없다면 예외처리 
			if (article == null) {
				throw new ArticleNotFoundException();
			}
			//articleNum의 해당하는 내용정보를 불러온다
			ArticleContent content = contentDao.selectById(conn, articleNum);
			//내용이없다며 예외처리
			if (content == null) {
				throw new ArticleContentNotFoundException();
			}
			
			//increaseReadCount가 있다면 true, 조회수를 증가시킴
			if (increaseReadCount) {
				articleDao.increaseReadCount(conn, articleNum);
			}
			
			//내용하나에 대한 댓글은 여러개를 보여줘야함
			//여기서 사용자가 댓글에 대한 페이지를 요청함 기본은 1

			//댓글은 SQL 으로 하나의 댓글번호기준으로 보여줘야함
			//int startRow = 1;
			//articleData객체를 리턴
			//댓글 여러개가담긴 객체임
			List<Reply> reply = replyDao.select(conn,articleNum);
			Reply replyContent = replyDao.selectById(conn, articleNum);
			return new ArticleData(article, content, replyContent, reply);

			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}	

}
