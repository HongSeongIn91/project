package article.service;

import java.util.List;

import article.model.Article;
import article.model.ArticleContent;
import article.model.Reply;

public class ArticleData {

	private Article article;
	private ArticleContent content;
	private Reply replyContent;
	private List<Reply> reply; // 화면에 출력할 게시글 목록을 보관
//	
	
	
	public ArticleData(Article article, ArticleContent content, Reply replyContent, List<Reply> reply) {
		this.article = article;
		this.content = content;
		this.replyContent = replyContent;
	}
	

	public Article getArticle() {
		return article;
	}

	public String getContent() {
		return content.getContent();
	}
	
	
	
	public Reply getReplyContent() {
		return replyContent;
	}


	public List<Reply> getReply() {
		return reply;
	}
}
