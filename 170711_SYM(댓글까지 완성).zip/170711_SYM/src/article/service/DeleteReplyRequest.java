package article.service;

import java.util.Map;

public class DeleteReplyRequest {
	
	private String userId;
	private int replyNumber;
	private int articleNo;
	private int replypageNo;

	
	public DeleteReplyRequest(String userId, int replyNumber, int articleNo, int replypageNo) {
		this.userId = userId;
		this.replyNumber = replyNumber;
		this.articleNo = articleNo;
		this.replypageNo = replypageNo;

	}

	public String getUserId() {
		return userId;
	}

	public int getReplyNumber() {
		return replyNumber;
	}


	public int getArticleNo() {
		return articleNo;
	}

	public int getReplypageNo() {
		return replypageNo;
	}

	public void validate(Map<String, Boolean> errors) {
		if(userId == null || userId.trim().isEmpty()) {
			errors.put("userId", Boolean.TRUE);
		}
	}
	
	
}
