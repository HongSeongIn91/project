package article.service;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.dao.ReplyDao;
import article.model.Reply;
import member.dao.JdbcUtil;

public class ModifyReplyService {

	private ReplyDao replyDao = new ReplyDao();

	public void modify(ModifyReplyRequest modReq) throws ClassNotFoundException, NamingException, SQLException {
		Connection conn = null;

		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);

//			Reply reply = replyDao.selectById(conn, modReq.getReplyNumber());

//			if (reply == null) {
//				throw new ReplyNotFoundException();
//			}
//			if (!canModify(modReq.getUserId(), reply)) {
//				throw new PermissionDeniedException();
//			}

			replyDao.update(conn, modReq.getReplyNumber(), modReq.getContent());

			conn.commit();

		} catch (SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException(e);
		} catch (PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		} finally {
			JdbcUtil.close(conn);
		}
	}

//	private boolean canModify(String modifyingUserId, Reply reply) {
//		return reply.getRp_m_id().equals(modifyingUserId);
//	}

}
