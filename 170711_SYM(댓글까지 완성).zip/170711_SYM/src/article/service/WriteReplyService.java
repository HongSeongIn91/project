package article.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.naming.NamingException;

import Connection.DBConnection;
import article.dao.ReplyDao;
import article.model.Reply;
import member.dao.JdbcUtil;

public class WriteReplyService {
	
	private ReplyDao replyDao = new ReplyDao();
	
	public Integer write(WriteReplyRequest req) throws ClassNotFoundException, NamingException {
			Connection conn = null;
			
			try {
				conn = DBConnection.getConnection();
				conn.setAutoCommit(false);
				
				Reply reply = toReply(req);
				
				Reply savedReply = replyDao.insert(conn, reply);
				if(savedReply == null) {
					throw new RuntimeException("fail to insert article");
				}
				
				conn.commit();
				return savedReply.getRp_rv_num();
				
				
			} catch (SQLException e) {
				JdbcUtil.rollback(conn);
				throw new RuntimeException(e);
			} catch (RuntimeException e) {
				JdbcUtil.rollback(conn);
				throw e;
			} finally {
				JdbcUtil.close(conn);
			}
	}

	// 댓글 번호, 감상평 번호, 댓글 작성자 아이디, 작성일, 댓글 내용 
	private Reply toReply(WriteReplyRequest req) {
		Date now =  new Date();
		return new Reply(null, req.getRp_rv_num(), req.getRp_m_id(), now, req.getRp_content());
	}
}
